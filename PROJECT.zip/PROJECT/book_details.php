<?php
require_once 'header.php';
require_once 'functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$userID = isset($_SESSION['userID']) ? (int)$_SESSION['userID'] : 0;
if (!isset($_SESSION['role']) || $userID === 0) {
    header('Location: welcome.php');
    exit;
}

$bookID = filter_input(INPUT_GET, 'bookID', FILTER_SANITIZE_NUMBER_INT);
$editMode = filter_input(INPUT_GET, 'edit', FILTER_SANITIZE_NUMBER_INT) == 1;
$book = getBookById($bookID);
$genres = getGenres();
$reviews = getReviews($bookID);

if (!$book) {
    header('Location: dashboard.php?error=' . urlencode('Book not found'));
    exit;
}

$notification = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !validateCsrfToken($_POST['csrf_token'])) {
        $error = 'Invalid CSRF token';
    } else {
        if (isset($_POST['update_book']) && $editMode) {
            $title = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING);
            $author = filter_input(INPUT_POST, 'author', FILTER_SANITIZE_STRING);
            $genreID = filter_input(INPUT_POST, 'genreID', FILTER_SANITIZE_NUMBER_INT);
            $imagePath = isset($_FILES['imagePath']) ? uploadImage($_FILES['imagePath']) : $book['imagePath'];
            
            if ($title && $author && $genreID) {
                if (updateBook($bookID, $title, $author, $genreID, $imagePath)) {
                    $notification = "Book '$title' updated successfully!";
                    addNotification($userID, $_SESSION['role'] === 'user' ? 'user' : 'staff', $notification);
                    header('Location: book_details.php?bookID=' . $bookID . '&notification=' . urlencode($notification));
                    exit;
                } else {
                    $error = 'Failed to update book';
                }
            } else {
                $error = 'All fields are required';
            }
        } elseif (isset($_POST['update_status'])) {
            $status = filter_input(INPUT_POST, 'status', FILTER_SANITIZE_STRING);
            if ($status) {
                if (updateBookStatus($bookID, $status, $userID)) {
                    $notification = "Status updated to '$status' for '{$book['title']}'!";
                    addNotification($userID, $_SESSION['role'] === 'user' ? 'user' : 'staff', $notification);
                    header('Location: book_details.php?bookID=' . $bookID . '&notification=' . urlencode($notification));
                    exit;
                } else {
                    $error = 'Invalid status update';
                }
            }
        } elseif (isset($_POST['add_review'])) {
            $reviewText = filter_input(INPUT_POST, 'reviewText', FILTER_SANITIZE_STRING);
            if ($reviewText) {
                if (addReview($bookID, $userID, $reviewText)) {
                    $notification = "Review added for '{$book['title']}'!";
                    addNotification($userID, $_SESSION['role'] === 'user' ? 'user' : 'staff', $notification);
                    header('Location: book_details.php?bookID=' . $bookID . '&notification=' . urlencode($notification));
                    exit;
                } else {
                    $error = 'Failed to add review';
                }
            } else {
                $error = 'Review text is required';
            }
        }
    }
}

$notification = filter_input(INPUT_GET, 'notification', FILTER_SANITIZE_STRING) ?? $notification;
$csrfToken = generateCsrfToken();
?>
<h2 class="text-3xl font-bold mb-6 text-indigo-700"><?php echo htmlspecialchars($book['title']); ?> Details</h2>
<nav class="mb-4">
  <ol class="flex space-x-2 text-gray-600">
    <li><a href="dashboard.php" class="text-indigo-600 hover:text-indigo-800">Home</a></li>
    <li>/</li>
    <li><a href="dashboard.php" class="text-indigo-600 hover:text-indigo-800">Dashboard</a></li>
    <li>/</li>
    <li><?php echo htmlspecialchars($book['title']); ?></li>
  </ol>
</nav>
<?php if ($notification): ?>
  <div id="notification" class="mb-4 p-3 bg-green-100 text-green-700 rounded-lg flex justify-between items-center fade-out">
    <span><?php echo htmlspecialchars($notification); ?></span>
    <button onclick="document.getElementById('notification').remove()" class="text-green-700 hover:text-green-900">✕</button>
  </div>
<?php endif; ?>
<?php if (isset($error)): ?>
  <div class="mb-4 p-3 bg-red-100 text-red-700 rounded-lg"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>
<div class="bg-white p-6 rounded-lg shadow-lg mb-6">
  <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
    <div>
      <?php if (isset($book['imagePath']) && !empty($book['imagePath'])): ?>
        <img src="<?php echo htmlspecialchars($book['imagePath']); ?>" alt="<?php echo htmlspecialchars($book['title']); ?>" class="w-full h-64 object-cover rounded">
      <?php else: ?>
        <div class="w-full h-64 bg-gray-200 rounded flex items-center justify-center">
          <span class="text-gray-500">No Image</span>
        </div>
      <?php endif; ?>
    </div>
    <div>
      <?php if ($editMode): ?>
        <form method="POST" enctype="multipart/form-data" class="space-y-4">
          <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
          <div>
            <label class="block text-gray-700 mb-1">Title</label>
            <input type="text" name="title" value="<?php echo htmlspecialchars($book['title']); ?>" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
          </div>
          <div>
            <label class="block text-gray-700 mb-1">Author</label>
            <input type="text" name="author" value="<?php echo htmlspecialchars($book['author']); ?>" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
          </div>
          <div>
            <label class="block text-gray-700 mb-1">Genre</label>
            <select name="genreID" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
              <?php foreach ($genres as $genre): ?>
                <option value="<?php echo $genre['genreID']; ?>" <?php echo $book['genreID'] == $genre['genreID'] ? 'selected' : ''; ?>>
                  <?php echo htmlspecialchars($genre['genreName']); ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div>
            <label class="block text-gray-700 mb-1">Cover Image</label>
            <input type="file" name="imagePath" accept="image/*" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500">
          </div>
          <div class="flex space-x-2">
            <button type="submit" name="update_book" class="bg-indigo-600 text-white p-2 rounded hover:bg-indigo-700 transition">Save</button>
            <a href="book_details.php?bookID=<?php echo $bookID; ?>" class="bg-gray-300 text-gray-700 p-2 rounded hover:bg-gray-400 transition">Cancel</a>
          </div>
        </form>
      <?php else: ?>
        <h3 class="text-xl font-bold text-indigo-700"><?php echo htmlspecialchars($book['title']); ?></h3>
        <p class="text-gray-600">by <?php echo htmlspecialchars($book['author']); ?></p>
        <p class="text-gray-600">Genre: <?php echo htmlspecialchars($book['genreName'] ?? 'Unknown'); ?></p>
        <p class="text-gray-600">Status: <?php echo htmlspecialchars($book['status'] ?? 'Unknown'); ?></p>
        <p class="text-gray-600">Added: <?php echo htmlspecialchars($book['addedDate']); ?></p>
        <a href="book_details.php?bookID=<?php echo $bookID; ?>&edit=1" class="text-indigo-600 hover:text-indigo-800 mt-2 inline-block">Edit Book</a>
        <form method="POST" class="mt-4">
          <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
          <input type="hidden" name="bookID" value="<?php echo $bookID; ?>">
          <label class="block text-gray-700 mb-1">Status</label>
          <select name="status" class="p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" onchange="this.form.submit()">
            <option value="Unread" <?php echo ($book['status'] ?? '') === 'Unread' ? 'selected' : ''; ?>>Unread</option>
            <option value="In Progress" <?php echo ($book['status'] ?? '') === 'In Progress' ? 'selected' : ''; ?>>In Progress</option>
            <option value="Read" <?php echo ($book['status'] ?? '') === 'Read' ? 'selected' : ''; ?>>Read</option>
            <option value="On Loan" <?php echo ($book['status'] ?? '') === 'On Loan' ? 'selected' : ''; ?>>On Loan</option>
            <option value="Damaged" <?php echo ($book['status'] ?? '') === 'Damaged' ? 'selected' : ''; ?>>Damaged</option>
            <option value="Reserved" <?php echo ($book['status'] ?? '') === 'Reserved' ? 'selected' : ''; ?>>Reserved</option>
          </select>
          <input type="hidden" name="update_status" value="1">
        </form>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="bg-white p-6 rounded-lg shadow-lg mb-6">
  <h3 class="text-xl font-bold mb-4 text-indigo-700">Reviews</h3>
  <?php if ($_SESSION['role'] === 'user'): ?>
    <form method="POST" class="mb-4">
      <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
      <input type="hidden" name="bookID" value="<?php echo $bookID; ?>">
      <label class="block text-gray-700 mb-1">Add Review</label>
      <textarea name="reviewText" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" rows="4" required></textarea>
      <button type="submit" name="add_review" class="mt-2 bg-indigo-600 text-white p-2 rounded hover:bg-indigo-700 transition">Submit Review</button>
    </form>
  <?php endif; ?>
  <?php if (empty($reviews)): ?>
    <p class="text-gray-600">No reviews yet.</p>
  <?php else: ?>
    <ul class="space-y-4">
      <?php foreach ($reviews as $review): ?>
        <li class="p-4 bg-gray-50 rounded-lg">
          <p class="text-gray-600"><?php echo htmlspecialchars($review['reviewText']); ?></p>
          <p class="text-sm text-gray-500">By <?php echo htmlspecialchars($review['username']); ?> on <?php echo $review['reviewDate']; ?></p>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</div>
<?php require_once 'footer.php'; ?>
</body>
</html>