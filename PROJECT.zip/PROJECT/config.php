<?php
if (!defined('PHPUNIT_TESTING') && session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Session timeout (30 minutes), only for non-test environments
if (!defined('PHPUNIT_TESTING')) {
    $timeout_duration = 1800;
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $timeout_duration)) {
        session_unset();
        session_destroy();
        header('Location: login.php?error=' . urlencode('Session timed out at ' . date('Y-m-d H:i:s', time()) . ' CEST'));
        exit;
    }
    $_SESSION['last_activity'] = time();
}

// Database connection
$conn = new mysqli('127.0.0.1', 'root', '', 'book_collection_tracker');
if ($conn->connect_error) {
    error_log("Connection failed: " . $conn->connect_error);
    die("Database connection failed. Please try again later.");
}
$conn->set_charset('utf8mb4');
?>