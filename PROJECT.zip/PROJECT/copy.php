<?php
require_once 'config.php';

// Session timeout and other existing functions unchanged...

// Modified getBooks
function getBooks($userID = null, $search = '', $genreID = '', $status = '', $minRating = null, $userIDFilter = '') {
    global $conn;
    $query = "SELECT b.*, g.genreName, bs.status
              FROM tblbooks b
              LEFT JOIN tblgenres g ON b.genreID = g.genreID
              LEFT JOIN tblbookstatus bs ON b.bookID = bs.bookID
              LEFT JOIN tblbook_ownership bo ON b.bookID = bo.bookID
              LEFT JOIN tblusers u ON bo.userID = u.userID
              WHERE 1=1";
    
    $params = [];
    $types = '';
    
    if ($userID && $_SESSION['role'] === 'user') {
        $query .= " AND bo.userID = ?";
        $params[] = $userID;
        $types .= 'i';
    }
    if (!empty($search)) {
        $query .= " AND (LOWER(b.title) LIKE LOWER(?) OR LOWER(b.author) LIKE LOWER(?))";
        $params[] = "%$search%";
        $params[] = "%$search%";
        $types .= 'ss';
    }
    if (!empty($genreID)) {
        $query .= " AND b.genreID = ?";
        $params[] = $genreID;
        $types .= 'i';
    }
    if (!empty($status)) {
        $query .= " AND bs.status = ?";
        $params[] = $status;
        $types .= 's';
    }
    if (!empty($userIDFilter) && $_SESSION['role'] !== 'user') {
        $query .= " AND bo.userID = ?";
        $params[] = $userIDFilter;
        $types .= 'i';
    }
    if ($minRating !== null && $userID) {
        if ($minRating == 0) {
            $query .= " AND NOT EXISTS (
                SELECT 1
                FROM tblratings r
                WHERE r.bookID = b.bookID
                AND r.userID = ?
            )";
            $params[] = $userID;
            $types .= 'i';
        } else {
            $query .= " AND EXISTS (
                SELECT 1
                FROM tblratings r
                WHERE r.bookID = b.bookID
                AND r.userID = ?
                AND r.rating BETWEEN ? AND ?
                AND r.ratedDate = (
                    SELECT MAX(r2.ratedDate)
                    FROM tblratings r2
                    WHERE r2.bookID = r.bookID
                    AND r2.userID = r.userID
                )
            )";
            $params[] = $userID;
            $params[] = $minRating;
            $params[] = $minRating + 0.99;
            $types .= 'idd';
        }
    }

    $query .= " GROUP BY b.bookID";

    $stmt = $conn->prepare($query);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $books = [];
    while ($row = $result->fetch_assoc()) {
        $books[] = $row;
    }
    $stmt->close();
    return $books;
}

// Modified getBookById
function getBookById($bookID) {
    global $conn;
    $bookID = (int)$bookID;
    $query = "SELECT b.*, g.genreName, bs.status
              FROM tblbooks b
              LEFT JOIN tblgenres g ON b.genreID = g.genreID
              LEFT JOIN tblbookstatus bs ON b.bookID = bs.bookID
              WHERE b.bookID = ?
              GROUP BY b.bookID";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $bookID);
    $stmt->execute();
    $result = $stmt->get_result();
    $book = $result->fetch_assoc();
    $stmt->close();
    return $book;
}

// Modified updateBookStatus
function updateBookStatus($bookID, $status, $updatedBy) {
    global $conn;
    if ($_SESSION['role'] !== 'user') {
        return false;
    }
    
    $bookID = (int)$bookID;
    $status = mysqli_real_escape_string($conn, $status);
    $updatedBy = (int)$updatedBy;
    
    // Verify status is valid
    $validStatuses = ['Unread', 'In Progress', 'Read', 'On Loan', 'Damaged', 'Reserved'];
    if (!in_array($status, $validStatuses)) {
        return false;
    }
    
    // Verify user owns the book
    $query = "SELECT COUNT(*) FROM tblbook_ownership WHERE bookID = ? AND userID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ii', $bookID, $updatedBy);
    $stmt->execute();
    $stmt->bind_result($ownershipCount);
    $stmt->fetch();
    $stmt->close();
    
    if ($ownershipCount == 0) {
        return false;
    }
    
    $query = "SELECT COUNT(*) FROM tblbookstatus WHERE bookID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $bookID);
    $stmt->execute();
    $stmt->bind_result($statusCount);
    $stmt->fetch();
    $stmt->close();
    
    if ($statusCount > 0) {
        $query = "UPDATE tblbookstatus SET status = ?, statusDate = CURDATE(), updatedBy = ? WHERE bookID = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('sii', $status, $updatedBy, $bookID);
    } else {
        $query = "INSERT INTO tblbookstatus (bookID, status, statusDate, updatedBy) VALUES (?, ?, CURDATE(), ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('isi', $bookID, $status, $updatedBy);
    }
    
    $result = $stmt->execute();
    if ($result) {
        $book = getBookById($bookID);
        logAction('Update Status', 'tblbookstatus', $bookID, $updatedBy, "Changed status to $status for book: {$book['title']}");
    }
    $stmt->close();
    return $result;
}

// Other functions unchanged...
?>