<?php
ob_start();
require_once 'header.php';
require_once 'functions.php';

if (!isset($_SESSION['userID']) || !isset($_SESSION['role'])) {
    header('Location: welcome.php');
    exit;
}

$search = filter_input(INPUT_GET, 'search', FILTER_SANITIZE_STRING) ?? '';
$genreID = filter_input(INPUT_GET, 'genreID', FILTER_SANITIZE_NUMBER_INT) ?? '';
$status = filter_input(INPUT_GET, 'status', FILTER_SANITIZE_STRING) ?? '';
$minRating = null;
if ($_SESSION['role'] === 'user') {
    $minRatingInput = filter_input(INPUT_GET, 'minRating', FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => 5]]);
    $minRating = ($minRatingInput === false) ? null : $minRatingInput;
}

$sort = filter_input(INPUT_GET, 'sort', FILTER_SANITIZE_STRING) ?? 'asc';
$page = filter_input(INPUT_GET, 'page', FILTER_SANITIZE_NUMBER_INT) ?? 1;
$itemsPerPage = filter_input(INPUT_GET, 'itemsPerPage', FILTER_SANITIZE_NUMBER_INT) ?? 9;
$viewMode = filter_input(INPUT_GET, 'viewMode', FILTER_SANITIZE_STRING) ?? 'detailed';
$userIDFilter = filter_input(INPUT_GET, 'userID', FILTER_SANITIZE_NUMBER_INT) ?? '';

$userID = ($_SESSION['role'] === 'user') ? $_SESSION['userID'] : null;
$books = getBooks($userID, $search, $genreID, $status, $minRating, $userIDFilter);
$genres = getGenres();
$users = getUsers();

$totalBooks = count($books);
$totalPages = ceil($totalBooks / $itemsPerPage);
$page = max(1, min($page, $totalPages));
$offset = ($page - 1) * $itemsPerPage;

if ($sort === 'desc') {
    $books = array_reverse($books);
}

$paginatedBooks = array_slice($books, $offset, $itemsPerPage);

$notification = filter_input(INPUT_GET, 'notification', FILTER_SANITIZE_STRING) ?? '';
$error = filter_input(INPUT_GET, 'error', FILTER_SANITIZE_STRING) ?? '';
$csrfToken = generateCsrfToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !validateCsrfToken($_POST['csrf_token'])) {
        $error = 'Invalid CSRF token';
        header('Location: dashboard.php?error=' . urlencode($error));
        exit;
    }

    if (isset($_POST['add_book'])) {
        $title = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING);
        $author = filter_input(INPUT_POST, 'author', FILTER_SANITIZE_STRING);
        $genreID = filter_input(INPUT_POST, 'genreID', FILTER_SANITIZE_NUMBER_INT);
        $assignedUserID = filter_input(INPUT_POST, 'assignedUserID', FILTER_SANITIZE_NUMBER_INT) ?? null;
        $imagePath = isset($_FILES['imagePath']) ? uploadImage($_FILES['imagePath']) : null;

        if ($title && $author && $genreID) {
            $result = addBook($title, $author, $genreID, $assignedUserID ?: $_SESSION['userID'], $imagePath);
            if (strpos($result, 'Success') === 0) {
                $notification = substr($result, 8);
                if ($imagePath === null && isset($_FILES['imagePath']) && $_FILES['imagePath']['size'] > 0) {
                    $error = 'Image upload failed; please try a smaller or different image';
                }
                if (!addNotification($_SESSION['userID'], $_SESSION['role'] === 'user' ? 'user' : 'staff', $notification)) {
                    $error = $error ? $error . '; failed to save notification' : 'Failed to save notification';
                }
                header('Location: dashboard.php?notification=' . urlencode($notification) . ($error ? '&error=' . urlencode($error) : ''));
            } else {
                $error = $result;
                header('Location: dashboard.php?error=' . urlencode($error));
            }
            exit;
        } else {
            $error = 'All fields are required';
            header('Location: dashboard.php?error=' . urlencode($error));
            exit;
        }
    } elseif (isset($_POST['update_status'])) {
        $bookID = filter_input(INPUT_POST, 'bookID', FILTER_SANITIZE_NUMBER_INT);
        $status = filter_input(INPUT_POST, 'status', FILTER_SANITIZE_STRING);
        if ($bookID && $status && in_array($status, ['Unread', 'In Progress', 'Read', 'On Loan', 'Damaged', 'Reserved'])) {
            if (updateBookStatus($bookID, $status, $_SESSION['userID'])) {
                $notification = 'Book status updated successfully!';
                addNotification($_SESSION['userID'], 'user', $notification);
                header('Location: dashboard.php?notification=' . urlencode($notification));
                exit;
            } else {
                $error = 'Failed to update status or you do not own this book';
                header('Location: dashboard.php?error=' . urlencode($error));
                exit;
            }
        } else {
            $error = 'Invalid book or status';
            header('Location: dashboard.php?error=' . urlencode($error));
            exit;
        }
    } elseif (isset($_POST['delete_book'])) {
        $bookID = filter_input(INPUT_POST, 'bookID', FILTER_SANITIZE_NUMBER_INT);
        if ($bookID) {
            if ($_SESSION['role'] === 'user') {
                $result = deleteUserBook($bookID, $_SESSION['userID']);
                if ($result === true) {
                    $notification = 'Your ownership of the book was removed successfully!';
                    addNotification($_SESSION['userID'], 'user', $notification);
                    header('Location: dashboard.php?notification=' . urlencode($notification));
                    exit;
                } else {
                    $error = $result ?: 'Failed to remove your ownership of the book';
                    header('Location: dashboard.php?error=' . urlencode($error));
                    exit;
                }
            } else {
                $result = deleteBook($bookID);
                if ($result === true) {
                    $notification = 'Book deleted successfully for all users!';
                    addNotification($_SESSION['userID'], $_SESSION['role'] === 'user' ? 'user' : 'staff', $notification);
                    header('Location: dashboard.php?notification=' . urlencode($notification));
                    exit;
                } else {
                    $error = $result ?: 'Failed to delete book';
                    header('Location: dashboard.php?error=' . urlencode($error));
                    exit;
                }
            }
        } else {
            $error = 'Invalid book';
            header('Location: dashboard.php?error=' . urlencode($error));
            exit;
        }
    } elseif (isset($_POST['rate_book'])) {
        $bookID = filter_input(INPUT_POST, 'bookID', FILTER_SANITIZE_NUMBER_INT);
        $rating = filter_input(INPUT_POST, 'rating', FILTER_SANITIZE_NUMBER_INT);
        if ($bookID && $rating && $rating >= 1 && $rating <= 5 && $_SESSION['role'] === 'user') {
            if (rateBook($bookID, $_SESSION['userID'], $rating)) {
                $notification = 'Book rated successfully!';
                addNotification($_SESSION['userID'], 'user', $notification);
                header('Location: dashboard.php?notification=' . urlencode($notification));
                exit;
            } else {
                $error = 'Failed to rate book';
                header('Location: dashboard.php?error=' . urlencode($error));
                exit;
            }
        } else {
            $error = 'Invalid rating or not authorized to rate';
            header('Location: dashboard.php?error=' . urlencode($error));
            exit;
        }
    }
}
?>

<style>
  html, body {
    height: 100%;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
  }
  .bg-gradient {
    background: linear-gradient(to right, #e0f2fe, #f3e8ff);
  }
  .fade-out {
    animation: fadeOut 3s forwards;
  }
  @keyframes fadeOut {
    to { opacity: 0; }
  }
  .welcome-text {
    animation: fadeIn 1s ease-in-out;
  }
  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }
  .compact-view .book-card {
    display: flex;
    align-items: center;
    padding: 8px;
  }
  .compact-view .book-card img {
    width: 48px;
    height: 72px;
    margin-right: 8px;
  }
  .compact-view .book-card .book-details {
    flex: 1;
  }
  .compact-view .book-card .book-actions {
    flex-shrink: 0;
  }
  .content-wrapper {
    flex: 1 0 auto;
  }
  .modal {
    display: none;
    position: fixed;
    z-index: 50;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0,0,0,0.4);
  }
  .modal-content {
    background-color: #fff;
    margin: 10% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
    max-width: 500px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
  }
  .close {
    color: #aaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
  }
  .close:hover,
  .close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
  }
</style>

<div class="bg-gradient-to-r from-indigo-500 to-purple-600 text-white py-10 mb-8 rounded-lg shadow-lg">
    <div class="container mx-auto px-4">
        <?php if ($_SESSION['role'] === 'user'): ?>
            <h1 class="text-4xl font-bold mb-2 welcome-text">Welcome, <?php echo htmlentities($_SESSION['username']); ?>!</h1>
            <p class="text-lg">Discover and manage your book collection with ease.</p>
        <?php elseif ($_SESSION['role'] === 'staff'): ?>
            <h1 class="text-4xl font-bold mb-2 welcome-text">Welcome, <?php echo htmlentities($_SESSION['username']); ?>!</h1>
            <p class="text-lg">Manage books and users efficiently.</p>
        <?php else: ?>
            <h1 class "text-4xl font-bold mb-2 welcome-text">Welcome, <?php echo htmlentities($_SESSION['username']); ?>!</h1>
            <p class="text-lg">Oversee the entire library system.</p>
        <?php endif; ?>
    </div>
</div>

<div class="content-wrapper">
    <div class="container mx-auto p-4 flex">
        <main class="flex-1 ml-4">
            <h2 class="text-3xl font-bold mb-6 text-indigo-700">Book Collection Dashboard</h2>
            <nav class="mb-4">
                <ol class="flex space-x-2 text-gray-600">
                    <li><a href="dashboard.php" class="text-indigo-600 hover:text-indigo-800">Home</a></li>
                    <li>/</li>
                    <li>Dashboard</li>
                </ol>
            </nav>

            <?php if ($notification): ?>
                <div id="notification" class="mb-4 p-3 bg-green-100 text-green-700 rounded-lg flex justify-between items-center fade-out">
                    <span><?php echo htmlentities($notification); ?></span>
                    <button onclick="document.getElementById('notification').remove()" class="text-green-700 hover:text-green-900">✕</button>
                </div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div id="error" class="mb-4 p-3 bg-red-100 text-red-700 rounded-lg flex justify-between items-center fade-out">
                    <span><?php echo htmlentities($error); ?></span>
                    <button onclick="document.getElementById('error').remove()" class="text-red-700 hover:text-red-900">✕</button>
                </div>
            <?php endif; ?>

            <div class="mb-6 bg-white p-6 rounded-lg shadow-lg">
                <h3 class="text-xl font-bold mb-4 text-indigo-700">Add New Book</h3>
                <form method="POST" enctype="multipart/form-data" class="flex flex-wrap gap-4">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlentities($csrfToken); ?>">
                    <div class="flex-1 min-w-[200px]">
                        <label class="block text-gray-700 mb-1 font-medium">Title</label>
                        <input type="text" name="title" required class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>
                    <div class="flex-1 min-w-[200px]">
                        <label class="block text-gray-700 mb-1 font-medium">Author</label>
                        <input type="text" name="author" required class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>
                    <div class="flex-1 min-w-[150px]">
                        <label class="block text-gray-700 mb-1 font-medium">Genre</label>
                        <select name="genreID" required class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <?php foreach ($genres as $genre): ?>
                                <option value="<?php echo $genre['genreID']; ?>"><?php echo htmlentities($genre['genreName']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php if ($_SESSION['role'] !== 'user'): ?>
                        <div class="flex-1 min-w-[200px]">
                            <label class="block text-gray-700 mb-1 font-medium">Assign to User</label>
                            <select name="assignedUserID" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                <option value="">Unassigned</option>
                                <?php foreach ($users as $user): ?>
                                    <option value="<?php echo $user['userID']; ?>"><?php echo htmlentities($user['username']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php endif; ?>
                    <div class="flex-1 min-w-[200px]">
                        <label class="block text-gray-700 mb-1 font-medium">Cover Image</label>
                        <input type="file" name="imagePath" accept="image/jpeg,image/png,image/gif" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>
                    <?php if ($_SESSION['role'] !== 'user'): ?>
                        <button type="submit" name="add_book" class="bg-indigo-600 text-white px-6 py-2 rounded hover:bg-indigo-700 transition mt-4">Add Book</button>
                    <?php else: ?>
                        <button type="submit" name="add_book" class="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700 transition mt-4 flex items-center gap-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                            Add Book
                        </button>
                    <?php endif; ?>
                </form>
            </div>

            <div class="mb-6 bg-white p-6 rounded-lg shadow-lg">
                <h3 class="text-xl font-bold mb-4 text-indigo-700">Filter Books</h3>
                <form method="GET" class="flex flex-wrap gap-4 items-end">
                    <div class="flex-1 min-w-[200px]">
                        <label class="block text-gray-700 mb-1 font-medium">Search Books</label>
                        <input type="text" name="search" value="<?php echo htmlentities($search); ?>" placeholder="Search by title or author..." class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>
                    <div class="flex-1 min-w-[150px]">
                        <label class="block text-gray-700 mb-1 font-medium">Genre</label>
                        <select name="genreID" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <option value="">All Genres</option>
                            <?php foreach ($genres as $genre): ?>
                                <option value="<?php echo $genre['genreID']; ?>" <?php echo ($genreID === (string)$genre['genreID']) ? 'selected' : ''; ?>>
                                    <?php echo htmlentities($genre['genreName']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="flex-1 min-w-[150px]">
                        <label class="block text-gray-700 mb-1 font-medium">Status</label>
                        <select name="status" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <option value="">All Statuses</option>
                            <option value="Unread" <?php echo $status === 'Unread' ? 'selected' : ''; ?>>Unread</option>
                            <option value="In Progress" <?php echo $status === 'In Progress' ? 'selected' : ''; ?>>In Progress</option>
                            <option value="Read" <?php echo $status === 'Read' ? 'selected' : ''; ?>>Read</option>
                            <option value="On Loan" <?php echo $status === 'On Loan' ? 'selected' : ''; ?>>On Loan</option>
                            <option value="Damaged" <?php echo $status === 'Damaged' ? 'selected' : ''; ?>>Damaged</option>
                            <option value="Reserved" <?php echo $status === 'Reserved' ? 'selected' : ''; ?>>Reserved</option>
                        </select>
                    </div>
                    <?php if ($_SESSION['role'] === 'user'): ?>
                        <div class="flex-1 min-w-[150px]">
                            <label class="block text-gray-700 mb-1 font-medium">Your Rating</label>
                            <select name="minRating" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                <option value="" <?php echo $minRating === null ? 'selected' : ''; ?>>All Ratings</option>
                                <option value="0" <?php echo $minRating === 0 ? 'selected' : ''; ?>>Unrated (0 ★)</option>
                                <option value="1" <?php echo $minRating === 1 ? 'selected' : ''; ?>>1 ★</option>
                                <option value="2" <?php echo $minRating === 2 ? 'selected' : ''; ?>>2 ★</option>
                                <option value="3" <?php echo $minRating === 3 ? 'selected' : ''; ?>>3 ★</option>
                                <option value="4" <?php echo $minRating === 4 ? 'selected' : ''; ?>>4 ★</option>
                                <option value="5" <?php echo $minRating === 5 ? 'selected' : ''; ?>>5 ★</option>
                            </select>
                        </div>
                    <?php endif; ?>
                    <?php if ($_SESSION['role'] !== 'user'): ?>
                        <div class="flex-1 min-w-[150px]">
                            <label class="block text-gray-700 mb-1 font-medium">Filter by User</label>
                            <select name="userID" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                <option value="">All Users</option>
                                <?php foreach ($users as $user): ?>
                                    <option value="<?php echo $user['userID']; ?>" <?php echo ($userIDFilter === (string)$user['userID']) ? 'selected' : ''; ?>>
                                        <?php echo htmlentities($user['username']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php endif; ?>
                    <div class="flex-1 min-w-[150px]">
                        <label class="block text-gray-700 mb-1 font-medium">Sort</label>
                        <select name="sort" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <option value="asc" <?php echo $sort === 'asc' ? 'selected' : ''; ?>>Ascending</option>
                            <option value="desc" <?php echo $sort === 'desc' ? 'selected' : ''; ?>>Descending</option>
                        </select>
                    </div>
                    <div class="flex-1 min-w-[150px]">
                        <label class="block text-gray-700 mb-1 font-medium">Items Per Page</label>
                        <select name="itemsPerPage" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <option value="9" <?php echo $itemsPerPage == 9 ? 'selected' : ''; ?>>9</option>
                            <option value="18" <?php echo $itemsPerPage == 18 ? 'selected' : ''; ?>>18</option>
                            <option value="36" <?php echo $itemsPerPage == 36 ? 'selected' : ''; ?>>36</option>
                            <option value="50" <?php echo $itemsPerPage == 50 ? 'selected' : ''; ?>>50</option>
                        </select>
                    </div>
                    <div class="flex-1 min-w-[150px]">
                        <label class="block text-gray-700 mb-1 font-medium">View Mode</label>
                        <select name="viewMode" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <option value="detailed" <?php echo $viewMode === 'detailed' ? 'selected' : ''; ?>>Detailed</option>
                            <option value="compact" <?php echo $viewMode === 'compact' ? 'selected' : ''; ?>>Compact</option>
                        </select>
                    </div>
                    <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded hover:bg-indigo-700 transition">Filter</button>
                </form>
            </div>

            <div class="mb-6">
                <button id="exportCsv" class="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700 transition mb-4 flex items-center gap-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                    Export to CSV
                </button>
                <?php if (empty($paginatedBooks)): ?>
                    <p class="text-gray-600 text-center">No books found. Add some books to get started!</p>
                <?php else: ?>
                    <div class="grid grid-cols-1 <?php echo $viewMode === 'detailed' ? 'sm:grid-cols-2 lg:grid-cols-3 gap-6' : 'gap-2 compact-view'; ?>">
                        <?php foreach ($paginatedBooks as $book): ?>
                            <?php
                            // Calculate $userOwns for both view modes
                            $userOwns = false;
                            if ($_SESSION['role'] === 'user') {
                                $owners = getBookOwners($book['bookID']);
                                foreach ($owners as $owner) {
                                    if ($owner['username'] === $_SESSION['username']) {
                                        $userOwns = true;
                                        break;
                                    }
                                }
                            }
                            ?>
                            <div class="bg-white rounded-lg shadow-md book-card <?php echo $viewMode === 'detailed' ? 'p-4 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1' : ''; ?>">
                                <a href="book_details.php?bookID=<?php echo $book['bookID']; ?>">
                                    <img 
                                        src="<?php echo $book['imagePath'] ? htmlentities($book['imagePath']) : 'Uploads/default_cover.jpg'; ?>" 
                                        alt="<?php echo htmlentities($book['title']); ?>" 
                                        class="<?php echo $viewMode === 'detailed' ? 'w-32 h-48 object-cover mx-auto mb-4 rounded' : ''; ?>"
                                    >
                                </a>
                                <div class="book-details">
                                    <h4 class="text-lg font-bold text-indigo-700"><?php echo htmlentities($book['title']); ?></h4>
                                    <p class="text-gray-700 flex items-center gap-2">
                                        <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                                        <?php echo htmlentities($book['author']); ?>
                                    </p>
                                    <?php if ($viewMode === 'detailed'): ?>
                                        <p class="text-gray-700 flex items-center gap-2">
                                            <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12h18M3 6h18M3 18h18"></path></svg>
                                            <?php echo htmlentities($book['genreName'] ?? 'Unknown'); ?>
                                        </p>
                                        <p class="text-gray-700 flex items-center gap-2">
                                            <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2"></path></svg>
                                            <?php echo htmlentities($book['status'] ?? 'Unknown'); ?>
                                        </p>
                                        <?php if ($_SESSION['role'] === 'user' && $userOwns): ?>
                                            <p class="text-gray-700 flex items-center gap-2">
                                                <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 14l9-5-9-5-9 5 9 5zm0 0l9-5-9-5-9 5 9 5zm0 0v7"></path>
                                                </svg>
                                                <?php echo htmlentities($_SESSION['username']); ?>
                                            </p>
                                        <?php elseif ($_SESSION['role'] !== 'user'): ?>
                                            <p class="text-gray-700 flex items-center gap-2">
                                                <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 14l9-5-9-5-9 5 9 5zm0 0l9-5-9-5-9 5 9 5zm0 0v7"></path>
                                                </svg>
                                                <a href="#" class="text-indigo-600 hover:underline view-owners" data-book-id="<?php echo $book['bookID']; ?>">View Owners</a>
                                            </p>
                                        <?php endif; ?>
                                        <?php if ($_SESSION['role'] === 'user'): ?>
                                            <p class="text-gray-700 flex items-center gap-2">
                                                <svg class="w-4 h-4 text-yellow-500" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path></svg>
                                                <?php
                                                $userRating = getUserLatestRating($book['bookID'], $_SESSION['userID']);
                                                echo $userRating !== null ? $userRating . ' ★' : 'N/A';
                                                ?>
                                            </p>
                                        <?php else: ?>
                                            <p class="text-gray-700 flex items-center gap-2">
                                                <svg class="w-4 h-4 text-yellow-500" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path></svg>
                                                <a href="#" class="text-indigo-600 hover:underline view-ratings" data-book-id="<?php echo $book['bookID']; ?>">View Ratings</a>
                                            </p>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                                <div class="book-actions <?php echo $viewMode === 'detailed' ? 'mt-4 flex gap-2 flex-wrap' : 'flex gap-1'; ?>">
                                    <?php if ($_SESSION['role'] === 'user' && $userOwns): ?>
                                        <form method="POST" class="inline">
                                            <input type="hidden" name="csrf_token" value="<?php echo htmlentities($csrfToken); ?>">
                                            <input type="hidden" name="bookID" value="<?php echo $book['bookID']; ?>">
                                            <select name="status" class="p-1 border rounded focus:ring-2 focus:ring-indigo-500">
                                                <option value="Unread" <?php echo ($book['status'] === 'Unread') ? 'selected' : ''; ?>>Unread</option>
                                                <option value="In Progress" <?php echo ($book['status'] === 'In Progress') ? 'selected' : ''; ?>>In Progress</option>
                                                <option value="Read" <?php echo ($book['status'] === 'Read') ? 'selected' : ''; ?>>Read</option>
                                                <option value="On Loan" <?php echo ($book['status'] === 'On Loan') ? 'selected' : ''; ?>>On Loan</option>
                                                <option value="Damaged" <?php echo ($book['status'] === 'Damaged') ? 'selected' : ''; ?>>Damaged</option>
                                                <option value="Reserved" <?php echo ($book['status'] === 'Reserved') ? 'selected' : ''; ?>>Reserved</option>
                                            </select>
                                            <button type="submit" name="update_status" class="bg-indigo-600 text-white p-1 rounded hover:bg-indigo-700 transition">Update</button>
                                        </form>
                                        <form method="POST" class="inline">
                                            <input type="hidden" name="csrf_token" value="<?php echo htmlentities($csrfToken); ?>">
                                            <input type="hidden" name="bookID" value="<?php echo $book['bookID']; ?>">
                                            <button type="submit" name="delete_book" class="bg-red-600 text-white p-1 rounded hover:bg-red-700 transition" onclick="return confirm('Are you sure you want to remove your ownership of this book?')">
                                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    <?php if ($_SESSION['role'] === 'user'): ?>
                                        <form method="POST" class="inline">
                                            <input type="hidden" name="csrf_token" value="<?php echo htmlentities($csrfToken); ?>">
                                            <input type="hidden" name="bookID" value="<?php echo $book['bookID']; ?>">
                                            <select name="rating" class="p-1 border rounded focus:ring-2 focus:ring-indigo-500">
                                                <option value="1">1 ★</option>
                                                <option value="2">2 ★</option>
                                                <option value="3">3 ★</option>
                                                <option value="4">4 ★</option>
                                                <option value="5">5 ★</option>
                                            </select>
                                            <button type="submit" name="rate_book" class="bg-yellow-600 text-white p-1 rounded hover:bg-yellow-700 transition">Rate</button>
                                        </form>
                                    <?php endif; ?>
                                    <?php if ($_SESSION['role'] === 'staff' || $_SESSION['role'] === 'admin'): ?>
                                        <form method="POST" class="inline">
                                            <input type="hidden" name="csrf_token" value="<?php echo htmlentities($csrfToken); ?>">
                                            <input type="hidden" name="bookID" value="<?php echo $book['bookID']; ?>">
                                            <button type="submit" name="delete_book" class="bg-red-600 text-white p-1 rounded hover:bg-red-700 transition" onclick="return confirm('Are you sure you want to delete this book for all users?')">
                                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    <?php if (($_SESSION['role'] === 'staff' || $_SESSION['role'] === 'admin') && $viewMode !== 'detailed'): ?>
                                        <a href="#" class="view-ratings text-indigo-600 hover:underline p-1" data-book-id="<?php echo $book['bookID']; ?>">View Ratings</a>
                                        <a href="#" class="view-owners text-indigo-600 hover:underline p-1" data-book-id="<?php echo $book['bookID']; ?>">View Owners</a>
                                        <a href="#" class="view-statuses text-indigo-600 hover:underline p-1" data-book-id="<?php echo $book['bookID']; ?>">View Statuses</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <?php if ($totalPages > 1): ?>
                <div class="flex justify-center gap-2">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&genreID=<?php echo $genreID; ?>&status=<?php echo urlencode($status); ?>&minRating=<?php echo ($minRating !== null && $_SESSION['role'] === 'user') ? $minRating : ''; ?>&sort=<?php echo $sort; ?>&itemsPerPage=<?php echo $itemsPerPage; ?>&viewMode=<?php echo $viewMode; ?>&userID=<?php echo $userIDFilter; ?>" 
                           class="p-2 rounded <?php echo $page === $i ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'; ?>">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
        </main>
    </div>

    <div id="ratingsModal" class="modal">
        <div class="modal-content">
            <span class="close">×</span>
            <h2 class="text-xl font-bold mb-4 text-indigo-700" id="modalRatingsBookTitle">Ratings of Book</h2>
            <div id="ratingsList" class="overflow-x-auto">
                <table class="min-w-full bg-white border rounded-lg">
                    <thead>
                        <tr>
                            <th class="py-2 px-4 border-b text-left text-gray-700">Username</th>
                            <th class="py-2 px-4 border-b text-left text-gray-700">Rating</th>
                            <th class="py-2 px-4 border-b text-left text-gray-700">Rated Date</th>
                        </tr>
                    </thead>
                    <tbody id="ratingsTableBody"></tbody>
                </table>
            </div>
        </div>
    </div>

    <div id="ownersModal" class="modal">
        <div class="modal-content">
            <span class="close">×</span>
            <h2 class="text-xl font-bold mb-4 text-indigo-700" id="modalBookTitle">Owners of Book</h2>
            <div id="ownersList" class="overflow-x-auto">
                <table class="min-w-full bg-white border rounded-lg">
                    <thead>
                        <tr>
                            <th class="py-2 px-4 border-b text-left text-gray-700">Username</th>
                            <th class="py-2 px-4 border-b text-left text-gray-700">Ownership Type</th>
                            <th class="py-2 px-4 border-b text-left text-gray-700">Added Date</th>
                        </tr>
                    </thead>
                    <tbody id="ownersTableBody"></tbody>
                </table>
            </div>
        </div>
    </div>

    <div id="statusesModal" class="modal">
        <div class="modal-content">
            <span class="close">×</span>
            <h2 class="text-xl font-bold mb-4 text-indigo-700" id="modalStatusBookTitle">Statuses of Book</h2>
            <div id="statusesList" class="overflow-x-auto">
                <table class="min-w-full bg-white border rounded-lg">
                    <thead>
                        <tr>
                            <th class="py-2 px-4 border-b text-left text-gray-700">Username</th>
                            <th class="py-2 px-4 border-b text-left text-gray-700">Status</th>
                            <th class="py-2 px-4 border-b text-left text-gray-700">Updated Date</th>
                        </tr>
                    </thead>
                    <tbody id="statusesTableBody"></tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/PapaParse/5.4.1/papaparse.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('exportCsv').addEventListener('click', function() {
        const data = <?php echo json_encode(array_map(function($book) {
            $row = [
                'Title' => $book['title'] ?? 'Unknown',
                'Author' => $book['author'] ?? 'Unknown',
                'Genre' => $book['genreName'] ?? 'Unknown',
                'Status' => $book['status'] ?? 'Unknown',
                'Added Date' => $book['addedDate'] ?? 'N/A'
            ];
            if ($_SESSION['role'] === 'user') {
                $userRating = getUserLatestRating($book['bookID'], $_SESSION['userID']);
                $row['Your Rating'] = $userRating !== null ? $userRating . ' ★' : 'N/A';
            }
            return $row;
        }, $paginatedBooks)); ?>;
        
        if (!data || data.length === 0) {
            alert('No data available to export.');
            return;
        }

        const csv = Papa.unparse(data, {
            quotes: true,
            delimiter: ',',
            header: true,
            newline: '\r\n'
        });

        const bom = '\uFEFF';
        const blob = new Blob([bom + csv], { type: 'text/csv;charset=utf-8' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.setAttribute('href', url);
        a.setAttribute('download', 'books_<?php echo date('Ymd_His'); ?>.csv');
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    });

    const ratingsModal = document.getElementById('ratingsModal');
    const modalRatingsBookTitle = document.getElementById('modalRatingsBookTitle');
    const ratingsTableBody = document.getElementById('ratingsTableBody');
    const viewRatingsLinks = document.getElementsByClassName('view-ratings');

    for (let link of viewRatingsLinks) {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const bookId = this.getAttribute('data-book-id');
            const bookTitle = this.closest('.book-card').querySelector('h4').textContent;

            modalRatingsBookTitle.textContent = `Ratings of ${bookTitle}`;
            ratingsTableBody.innerHTML = '<tr><td colspan="3" class="py-2 px-4 text-gray-700 text-center">Loading...</td></tr>';

            fetch(`get_ratings.php?bookID=${bookId}`)
                .then(response => response.json())
                .then(data => {
                    ratingsTableBody.innerHTML = '';
                    if (!Array.isArray(data) || data.length === 0) {
                        ratingsTableBody.innerHTML = '<tr><td colspan="3" class="py-2 px-4 text-gray-700 text-center">No ratings found</td></tr>';
                    } else if (data.error) {
                        ratingsTableBody.innerHTML = `<tr><td colspan="3" class="py-2 px-4 text-red-700 text-center">${data.error}</td></tr>`;
                    } else {
                        data.forEach(rating => {
                            const row = document.createElement('tr');
                            row.innerHTML = `
                                <td class="py-2 px-4 border-b text-gray-700">${rating.username || 'Unknown'}</td>
                                <td class="py-2 px-4 border-b text-gray-700">${rating.rating} ★</td>
                                <td class="py-2 px-4 border-b text-gray-700">${rating.ratedDate || 'N/A'}</td>
                            `;
                            ratingsTableBody.appendChild(row);
                        });
                    }
                    ratingsModal.style.display = 'block';
                })
                .catch(error => {
                    console.error('Error fetching ratings:', error);
                    ratingsTableBody.innerHTML = '<tr><td colspan="3" class="py-2 px-4 text-red-700 text-center">Error loading ratings</td></tr>';
                    ratingsModal.style.display = 'block';
                });
        });
    }

    const ownersModal = document.getElementById('ownersModal');
    const modalBookTitle = document.getElementById('modalBookTitle');
    const ownersTableBody = document.getElementById('ownersTableBody');
    const viewOwnersLinks = document.getElementsByClassName('view-owners');

    for (let link of viewOwnersLinks) {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const bookId = this.getAttribute('data-book-id');
            const bookTitle = this.closest('.book-card').querySelector('h4').textContent;

            modalBookTitle.textContent = `Owners of ${bookTitle}`;
            ownersTableBody.innerHTML = '<tr><td colspan="3" class="py-2 px-4 text-gray-700 text-center">Loading...</td></tr>';

            fetch(`get_owners.php?bookID=${bookId}`)
                .then(response => response.json())
                .then(data => {
                    ownersTableBody.innerHTML = '';
                    if (!Array.isArray(data) || data.length === 0) {
                        ownersTableBody.innerHTML = '<tr><td colspan="3" class="py-2 px-4 text-gray-700 text-center">No owners found</td></tr>';
                    } else if (data.error) {
                        ownersTableBody.innerHTML = `<tr><td colspan="3" class="py-2 px-4 text-red-700 text-center">${data.error}</td></tr>`;
                    } else {
                        data.forEach(owner => {
                            const row = document.createElement('tr');
                            row.innerHTML = `
                                <td class="py-2 px-4 border-b text-gray-700">${owner.username || 'Unknown'}</td>
                                <td class="py-2 px-4 border-b text-gray-700">${owner.ownershipType || 'N/A'}</td>
                                <td class="py-2 px-4 border-b text-gray-700">${owner.addedDate || 'N/A'}</td>
                            `;
                            ownersTableBody.appendChild(row);
                        });
                    }
                    ownersModal.style.display = 'block';
                })
                .catch(error => {
                    console.error('Error fetching owners:', error);
                    ownersTableBody.innerHTML = '<tr><td colspan="3" class="py-2 px-4 text-red-700 text-center">Error loading owners</td></tr>';
                    ownersModal.style.display = 'block';
                });
        });
    }

    const statusesModal = document.getElementById('statusesModal');
    const modalStatusBookTitle = document.getElementById('modalStatusBookTitle');
    const statusesTableBody = document.getElementById('statusesTableBody');
    const viewStatusesLinks = document.getElementsByClassName('view-statuses');

    for (let link of viewStatusesLinks) {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const bookId = this.getAttribute('data-book-id');
            const bookTitle = this.closest('.book-card').querySelector('h4').textContent;

            modalStatusBookTitle.textContent = `Statuses of ${bookTitle}`;
            statusesTableBody.innerHTML = '<tr><td colspan="3" class="py-2 px-4 text-gray-700 text-center">Loading...</td></tr>';

            fetch(`get_statuses.php?bookID=${bookId}`)
                .then(response => response.json())
                .then(data => {
                    statusesTableBody.innerHTML = '';
                    if (!Array.isArray(data) || data.length === 0) {
                        statusesTableBody.innerHTML = '<tr><td colspan="3" class="py-2 px-4 text-gray-700 text-center">No statuses found</td></tr>';
                    } else if (data.error) {
                        statusesTableBody.innerHTML = `<tr><td colspan="3" class="py-2 px-4 text-red-700 text-center">${data.error}</td></tr>`;
                    } else {
                        data.forEach(status => {
                            const row = document.createElement('tr');
                            row.innerHTML = `
                                <td class="py-2 px-4 border-b text-gray-700">${status.username || 'Unknown'}</td>
                                <td class="py-2 px-4 border-b text-gray-700">${status.status || 'N/A'}</td>
                                <td class="py-2 px-4 border-b text-gray-700">${status.statusDate || 'N/A'}</td>
                            `;
                            statusesTableBody.appendChild(row);
                        });
                    }
                    statusesModal.style.display = 'block';
                })
                .catch(error => {
                    console.error('Error fetching statuses:', error);
                    statusesTableBody.innerHTML = '<tr><td colspan="3" class="py-2 px-4 text-red-700 text-center">Error loading statuses</td></tr>';
                    statusesModal.style.display = 'block';
                });
        });
    }

    const closeButtons = document.getElementsByClassName('close');
    for (let btn of closeButtons) {
        btn.addEventListener('click', function() {
            ratingsModal.style.display = 'none';
            ownersModal.style.display = 'none';
            statusesModal.style.display = 'none';
        });
    }

    window.addEventListener('click', function(event) {
        if (event.target === ratingsModal) {
            ratingsModal.style.display = 'none';
        }
        if (event.target === ownersModal) {
            ownersModal.style.display = 'none';
        }
        if (event.target === statusesModal) {
            statusesModal.style.display = 'none';
        }
    });
});
</script>

<?php require_once 'footer.php'; ?>