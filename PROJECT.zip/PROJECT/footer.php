<?php
// footer.php
?>
<footer class="bg-gradient-to-r from-indigo-600 to-purple-700 text-white py-4">
  <div class="container mx-auto px-4 text-center text-sm">
    <span>© <?php echo date('Y'); ?> Book Collection Tracker. All rights reserved.</span>
    <div class="mt-2 space-x-4">
      <a href="dashboard.php" class="text-gray-300 hover:text-white transition-colors duration-300">Home</a>
      <span>|</span>
      <a href="terms.php" class="text-gray-300 hover:text-white transition-colors duration-300">Terms & Conditions</a>
      <span>|</span>
      <a href="privacy.php" class="text-gray-300 hover:text-white transition-colors duration-300">Privacy Policy</a>
    </div>
  </div>
</footer>