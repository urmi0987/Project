<?php
require_once 'config.php';

// Session timeout (30 minutes)
$timeout_duration = 1800;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $timeout_duration)) {
    session_unset();
    session_destroy();
    header('Location: login.php?error=' . urlencode('Session timed out at ' . date('Y-m-d H:i:s', time()) . ' CEST'));
    exit;
}
$_SESSION['last_activity'] = time();

// Generate CSRF token
function generateCsrfToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Validate CSRF token
function validateCsrfToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Log staff actions
function logAction($action, $tableName, $recordID, $staffID, $conn, $details = null) {
    $action = mysqli_real_escape_string($conn, $action);
    $tableName = mysqli_real_escape_string($conn, $tableName);
    $recordID = (int)$recordID;
    $staffID = (int)$staffID;
    $details = $details ? mysqli_real_escape_string($conn, $details) : null;
    $query = "INSERT INTO tblauditlogs (action, tableName, recordID, staffID, actionDate, details) VALUES (?, ?, ?, ?, NOW(), ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('sssis', $action, $tableName, $recordID, $staffID, $details);
    $success = $stmt->execute();
    $stmt->close();
    return $success;
}

// Notification functions
function addNotification($recipientID, $recipientType, $message) {
    global $conn;
    $message = mysqli_real_escape_string($conn, $message);
    $recipientID = (int)$recipientID;
    $userID = $recipientType === 'user' ? $recipientID : NULL;
    $staffID = $recipientType === 'staff' ? $recipientID : NULL;
    $query = "INSERT INTO tblnotifications (userID, staffID, message, createdDate, isRead) 
              VALUES (" . ($userID !== NULL ? $userID : 'NULL') . ", " . ($staffID !== NULL ? $staffID : 'NULL') . ", '$message', NOW(), 0)";
    $result = mysqli_query($conn, $query);
    if (!$result) {
        error_log("Notification insert failed: " . mysqli_error($conn));
        return false;
    }
    return true;
}

function getNotifications($recipientID, $recipientType) {
    global $conn;
    $recipientID = (int)$recipientID;
    $column = $recipientType === 'user' ? 'userID' : 'staffID';
    $query = "SELECT * FROM tblnotifications WHERE $column = $recipientID ORDER BY createdDate DESC LIMIT 10";
    $result = mysqli_query($conn, $query);
    $notifications = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $notifications[] = $row;
    }
    return $notifications;
}

function getUnreadNotificationCount($recipientID, $recipientType) {
    global $conn;
    $recipientID = (int)$recipientID;
    $column = $recipientType === 'user' ? 'userID' : 'staffID';
    $query = "SELECT COUNT(*) FROM tblnotifications WHERE $column = $recipientID AND isRead = 0";
    $result = mysqli_query($conn, $query);
    return (int)mysqli_fetch_row($result)[0];
}

function markNotificationsAsRead($recipientID, $recipientType) {
    global $conn;
    $recipientID = (int)$recipientID;
    $column = $recipientType === 'user' ? 'userID' : 'staffID';
    $query = "UPDATE tblnotifications SET isRead = 1 WHERE $column = $recipientID AND isRead = 0";
    return mysqli_query($conn, $query);
}

// User functions
function userLogin($email, $password, $conn) {
    $stmt = $conn->prepare("SELECT userID AS id, username, email, password, 'user' AS role FROM tblusers WHERE email = ?");
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    
    if ($user && password_verify($password, $user['password'])) {
        $id = $user['id'];
        $updateStmt = $conn->prepare("UPDATE tblusers SET lastLogin = NOW() WHERE userID = ?");
        $updateStmt->bind_param('i', $id);
        $updateStmt->execute();
        $updateStmt->close();
        return [
            'userID' => $id,
            'username' => $user['username'],
            'email' => $user['email'],
            'role' => $user['role']
        ];
    }
    $stmt->close();
    return false;
}

function staffLogin($email, $password) {
    global $conn;
    $email = mysqli_real_escape_string($conn, $email);
    $query = "SELECT staffID AS id, staffName AS username, email, password, IF(isAdmin, 'admin', 'staff') AS role FROM tblstaff WHERE email = '$email'";
    $result = mysqli_query($conn, $query);
    $user = mysqli_fetch_assoc($result);
    
    if ($user && password_verify($password, $user['password'])) {
        $id = $user['id'];
        return [
            'userID' => $id,
            'username' => $user['username'],
            'email' => $user['email'],
            'role' => $user['role']
        ];
    }
    return false;
}

function signup($username, $email, $password, $conn) {
    $username = mysqli_real_escape_string($conn, $username);
    $email = mysqli_real_escape_string($conn, $email);
    $query = "SELECT COUNT(*) FROM tblusers WHERE username = '$username' OR email = '$email'";
    $result = mysqli_query($conn, $query);
    if (mysqli_fetch_row($result)[0] > 0) {
        return false;
    }
    
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $query = "INSERT INTO tblusers (username, email, password, joinDate) 
              VALUES ('$username', '$email', '$hashedPassword', CURDATE())";
    return mysqli_query($conn, $query);
}

function getUsers() {
    global $conn;
    $query = "SELECT u.userID, u.username, u.email, u.joinDate, u.lastLogin, 
                     COUNT(bo.bookID) AS bookCount
              FROM tblusers u
              LEFT JOIN tblbook_ownership bo ON u.userID = bo.userID
              GROUP BY u.userID
              ORDER BY u.joinDate DESC";
    $result = mysqli_query($conn, $query);
    $users = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $users[] = $row;
    }
    return $users;
}

function updateUser($userID, $username, $email, $conn, $password = null) {
    $stmt = $conn->prepare("SELECT COUNT(*) FROM tblusers WHERE (username = ? OR email = ?) AND userID != ?");
    $stmt->bind_param('ssi', $username, $email, $userID);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->fetch_row()[0] > 0) {
        return false;
    }

    $query = "UPDATE tblusers SET username = ?, email = ?";
    $types = 'ss';
    $params = [$username, $email];
    if ($password) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $query .= ", password = ?";
        $types .= 's';
        $params[] = $hashedPassword;
    }
    $query .= " WHERE userID = ?";
    $types .= 'i';
    $params[] = $userID;

    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $success = $stmt->execute();
    if ($success && isset($_SESSION['role']) && $_SESSION['role'] !== 'user') {
        logAction('Update User', 'tblusers', $userID, $_SESSION['userID'], $conn, "Updated user: $username");
    }
    $stmt->close();
    return $success;
}

function deleteUser($userID, $conn) {
    $stmt = $conn->prepare("SELECT COUNT(*) FROM tblbook_ownership WHERE userID = ?");
    $stmt->bind_param('i', $userID);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->fetch_row()[0] > 0) {
        return false;
    }

    // Store username before deletion for logging
    $stmt = $conn->prepare("SELECT username FROM tblusers WHERE userID = ?");
    $stmt->bind_param('i', $userID);
    $stmt->execute();
    $result = $stmt->get_result();
    $username = null;
    if ($user = $result->fetch_assoc()) {
        $username = $user['username'];
    }

    $stmt = $conn->prepare("DELETE FROM tblusers WHERE userID = ?");
    $stmt->bind_param('i', $userID);
    $success = $stmt->execute();
    if ($success && isset($_SESSION['role']) && $_SESSION['role'] !== 'user' && $username) {
        logAction('Delete User', 'tblusers', $userID, $_SESSION['userID'], $conn, "Deleted user: $username");
    }
    $stmt->close();
    return $success;
}

// Staff functions
function getStaff() {
    global $conn;
    $query = "SELECT staffID, staffName, email, IF(isAdmin, 'admin', 'staff') AS role, isAdmin, hireDate 
              FROM tblstaff 
              ORDER BY hireDate DESC";
    $result = mysqli_query($conn, $query);
    if (!$result) {
        error_log("getStaff failed: " . mysqli_error($conn));
        return [];
    }
    $staff = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $staff[] = $row;
    }
    return $staff;
}

function addStaff($staffName, $email, $password, $role, $isAdmin) {
    global $conn;
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
        return false; // Only admin can add staff
    }
    $staffName = mysqli_real_escape_string($conn, $staffName);
    $email = mysqli_real_escape_string($conn, $email);
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $role = mysqli_real_escape_string($conn, $role);
    $isAdmin = (int)$isAdmin;

    $query = "SELECT COUNT(*) FROM tblstaff WHERE email = '$email'";
    $result = mysqli_query($conn, $query);
    if (mysqli_fetch_row($result)[0] > 0) {
        return false; // Email already exists
    }

    $query = "INSERT INTO tblstaff (staffName, email, password, role, isAdmin, hireDate) 
              VALUES ('$staffName', '$email', '$hashedPassword', '$role', $isAdmin, CURDATE())";
    if (mysqli_query($conn, $query)) {
        $staffID = mysqli_insert_id($conn);
        logAction('Add Staff', 'tblstaff', $staffID, $_SESSION['userID'], "Added staff: $staffName");
        return true;
    }
    return false;
}

function updateStaff($staffID, $staffName, $email, $password, $role, $isAdmin) {
    global $conn;
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
        return false; // Only admin can update staff
    }
    $staffID = (int)$staffID;
    $staffName = mysqli_real_escape_string($conn, $staffName);
    $email = mysqli_real_escape_string($conn, $email);
    $role = mysqli_real_escape_string($conn, $role);
    $isAdmin = (int)$isAdmin;

    $query = "SELECT COUNT(*) FROM tblstaff WHERE email = '$email' AND staffID != $staffID";
    $result = mysqli_query($conn, $query);
    if (mysqli_fetch_row($result)[0] > 0) {
        return false; // Email already exists for another staff
    }

    $updateQuery = "UPDATE tblstaff SET staffName = '$staffName', email = '$email', role = '$role', isAdmin = $isAdmin";
    if ($password) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $updateQuery .= ", password = '$hashedPassword'";
    }
    $updateQuery .= " WHERE staffID = $staffID";

    if (mysqli_query($conn, $updateQuery)) {
        logAction('Update Staff', 'tblstaff', $staffID, $_SESSION['userID'], "Updated staff: $staffName");
        return true;
    }
    return false;
}

function deleteStaff($staffID) {
    global $conn;
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
        return false; // Only admin can delete staff
    }
    $staffID = (int)$staffID;
    $query = "SELECT COUNT(*) FROM tblgenres WHERE createdBy = $staffID";
    $result = mysqli_query($conn, $query);
    if (mysqli_fetch_row($result)[0] > 0) {
        return false; // Cannot delete staff with associated genres
    }

    $query = "DELETE FROM tblstaff WHERE staffID = $staffID";
    if (mysqli_query($conn, $query)) {
        $staff = mysqli_fetch_assoc(mysqli_query($conn, "SELECT staffName FROM tblstaff WHERE staffID = $staffID"));
        logAction('Delete Staff', 'tblstaff', $staffID, $_SESSION['userID'], "Deleted staff: {$staff['staffName']}");
        return true;
    }
    return false;
}
function getUserLatestRating($bookID, $userID) {
    global $conn;
    $stmt = $conn->prepare("SELECT rating FROM tblratings WHERE bookID = ? AND userID = ? ORDER BY ratedDate DESC LIMIT 1");
    $stmt->bind_param('ii', $bookID, $userID);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    return $row ? $row['rating'] : null;
}
// Book functions
function getBooks($userID = null, $search = '', $genreID = '', $status = '', $minRating = null, $userIDFilter = '') {
    global $conn;
    $query = "SELECT b.*, g.genreName, bs.status
              FROM tblbooks b
              LEFT JOIN tblgenres g ON b.genreID = g.genreID
              LEFT JOIN tblbookstatus bs ON b.bookID = bs.bookID
              LEFT JOIN tblbook_ownership bo ON b.bookID = bo.bookID
              LEFT JOIN tblusers u ON bo.userID = u.userID
              WHERE 1=1";
    
    $params = [];
    $types = '';
    
    if ($userID && $_SESSION['role'] === 'user') {
        $query .= " AND bo.userID = ?";
        $params[] = $userID;
        $types .= 'i';
    }
    if (!empty($search)) {
        $query .= " AND (LOWER(b.title) LIKE LOWER(?) OR LOWER(b.author) LIKE LOWER(?))";
        $params[] = "%$search%";
        $params[] = "%$search%";
        $types .= 'ss';
    }
    if (!empty($genreID)) {
        $query .= " AND b.genreID = ?";
        $params[] = $genreID;
        $types .= 'i';
    }
    if (!empty($status)) {
        $query .= " AND bs.status = ?";
        $params[] = $status;
        $types .= 's';
    }
    if (!empty($userIDFilter) && $_SESSION['role'] !== 'user') {
        $query .= " AND bo.userID = ?";
        $params[] = $userIDFilter;
        $types .= 'i';
    }
    if ($minRating !== null && $userID) {
        if ($minRating == 0) {
            $query .= " AND NOT EXISTS (
                SELECT 1
                FROM tblratings r
                WHERE r.bookID = b.bookID
                AND r.userID = ?
            )";
            $params[] = $userID;
            $types .= 'i';
        } else {
            $query .= " AND EXISTS (
                SELECT 1
                FROM tblratings r
                WHERE r.bookID = b.bookID
                AND r.userID = ?
                AND r.rating BETWEEN ? AND ?
                AND r.ratedDate = (
                    SELECT MAX(r2.ratedDate)
                    FROM tblratings r2
                    WHERE r2.bookID = r.bookID
                    AND r2.userID = r.userID
                )
            )";
            $params[] = $userID;
            $params[] = $minRating;
            $params[] = $minRating + 0.99;
            $types .= 'idd';
        }
    }

    $query .= " GROUP BY b.bookID";

    $stmt = $conn->prepare($query);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $books = [];
    while ($row = $result->fetch_assoc()) {
        $books[] = $row;
    }
    $stmt->close();
    return $books;
}

function getBookById($bookID) {
    global $conn;
    $bookID = (int)$bookID;
    $query = "SELECT b.*, g.genreName, bs.status
              FROM tblbooks b
              LEFT JOIN tblgenres g ON b.genreID = g.genreID
              LEFT JOIN tblbookstatus bs ON b.bookID = bs.bookID
              WHERE b.bookID = ?
              GROUP BY b.bookID";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $bookID);
    $stmt->execute();
    $result = $stmt->get_result();
    $book = $result->fetch_assoc();
    $stmt->close();
    return $book;
}

function getBookOwners($bookID) {
    global $conn;
    $bookID = (int)$bookID;
    $query = "SELECT u.username, bo.ownershipType, bo.addedDate
              FROM tblbook_ownership bo
              JOIN tblusers u ON bo.userID = u.userID
              WHERE bo.bookID = $bookID
              ORDER BY bo.addedDate DESC";
    $result = mysqli_query($conn, $query);
    $owners = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $owners[] = $row;
    }
    return $owners;
}

function addBook($title, $author, $genreID, $assignedUserID, $imagePath = null) {
    global $conn;
    $title = mysqli_real_escape_string($conn, $title);
    $author = mysqli_real_escape_string($conn, $author);
    $genreID = (int)$genreID;
    $assignedUserID = $assignedUserID ? (int)$assignedUserID : null;
    $imagePath = $imagePath ? mysqli_real_escape_string($conn, $imagePath) : null;

    // Check for existing book with the same title and author
    $checkQuery = "SELECT bookID FROM tblbooks WHERE LOWER(title) = LOWER('$title') AND LOWER(author) = LOWER('$author')";
    $result = mysqli_query($conn, $checkQuery);
    if ($result && mysqli_num_rows($result) > 0) {
        $existingBook = mysqli_fetch_assoc($result);
        $bookID = $existingBook['bookID'];

        // Check if the assigned user already owns this book
        if ($assignedUserID) {
            $ownershipQuery = "SELECT COUNT(*) FROM tblbook_ownership bo WHERE bo.bookID = $bookID AND bo.userID = $assignedUserID";
            $ownershipResult = mysqli_query($conn, $ownershipQuery);
            if (mysqli_fetch_row($ownershipResult)[0] > 0) {
                return "Error: User already owns this book titled '$title' by $author.";
            }

            $insertOwnershipQuery = "INSERT INTO tblbook_ownership (bookID, userID, ownershipType, addedDate) VALUES ($bookID, $assignedUserID, 'Co-owner', CURDATE())";
            if (!mysqli_query($conn, $insertOwnershipQuery)) {
                return "Error: Failed to add user as co-owner for '$title' by $author.";
            }

            $statusQuery = "INSERT INTO tblbookstatus (bookID, status, statusDate, updatedBy) VALUES ($bookID, 'Available', CURDATE(), $assignedUserID)";
            if (!mysqli_query($conn, $statusQuery)) {
                return "Error: Failed to update status for '$title' by $author.";
            }

            $notification = "You are now a co-owner of '$title' by $author!";
            if (!addNotification($assignedUserID, 'user', $notification)) {
                return "Error: Book added, but notification failed for '$title'.";
            }
            if ($_SESSION['role'] !== 'user') {
                logAction('Add Book', 'tblbooks', $bookID, $_SESSION['userID'], "Added as co-owner: $title, userID: $assignedUserID");
            }
            return "Success: Added as co-owner of '$title' by $author!";
        }
        return "Error: Book '$title' by $author already exists and cannot be unassigned.";
    }

    // Insert new book if no duplicate found
    $insertBookQuery = "INSERT INTO tblbooks (title, author, genreID, addedDate" . ($imagePath ? ", imagePath" : "") . ") 
                        VALUES ('$title', '$author', $genreID, CURDATE()" . ($imagePath ? ", '$imagePath'" : "") . ")";
    if (!mysqli_query($conn, $insertBookQuery)) {
        return "Error: Failed to add new book '$title' by $author.";
    }

    $bookID = mysqli_insert_id($conn);

    // Insert ownership record
    $userID = $assignedUserID ?: $_SESSION['userID'];
    $ownershipType = $assignedUserID ? 'Co-owner' : 'Owner';
    $insertOwnershipQuery = "INSERT INTO tblbook_ownership (bookID, userID, ownershipType, addedDate) VALUES ($bookID, $userID, '$ownershipType', CURDATE())";
    if (!mysqli_query($conn, $insertOwnershipQuery)) {
        return "Error: Failed to set ownership for new book '$title' by $author.";
    }

    $statusQuery = "INSERT INTO tblbookstatus (bookID, status, statusDate, updatedBy) VALUES ($bookID, 'Available', CURDATE(), $userID)";
    if (!mysqli_query($conn, $statusQuery)) {
        return "Error: Failed to set status for new book '$title' by $author.";
    }

    $notification = "Book '$title' by $author added successfully!";
    if (!addNotification($userID, 'user', $notification)) {
        return "Error: Book added, but notification failed for '$title'.";
    }
    if ($_SESSION['role'] !== 'user') {
        logAction('Add Book', 'tblbooks', $bookID, $_SESSION['userID'], "Added new book: $title, userID: $userID");
    }
    return "Success: Added new book '$title' by $author!";
}

function updateBook($bookID, $title, $author, $genreID, $imagePath = null) {
    global $conn;
    $bookID = (int)$bookID;
    $title = mysqli_real_escape_string($conn, $title);
    $author = mysqli_real_escape_string($conn, $author);
    $genreID = (int)$genreID;
    $imagePath = $imagePath ? mysqli_real_escape_string($conn, $imagePath) : null;
    
    $query = "UPDATE tblbooks SET title = '$title', author = '$author', genreID = $genreID";
    if ($imagePath) {
        $query .= ", imagePath = '$imagePath'";
    }
    $query .= " WHERE bookID = $bookID";
    
    if (mysqli_query($conn, $query)) {
        if ($_SESSION['role'] !== 'user') {
            logAction('Update Book', 'tblbooks', $bookID, $_SESSION['userID'], "Updated book: $title");
        }
        return true;
    }
    return false;
}

function deleteBook($bookID) {
    global $conn;
    $bookID = (int)$bookID;
    $book = getBookById($bookID);
    mysqli_begin_transaction($conn);
    try {
        $query = "DELETE FROM tblbookstatus WHERE bookID = $bookID";
        mysqli_query($conn, $query);
        $query = "DELETE FROM tblratings WHERE bookID = $bookID";
        mysqli_query($conn, $query);
        $query = "DELETE FROM tblreviews WHERE bookID = $bookID";
        mysqli_query($conn, $query);
        $query = "DELETE FROM tblbook_ownership WHERE bookID = $bookID";
        mysqli_query($conn, $query);
        $query = "DELETE FROM tblbooks WHERE bookID = $bookID";
        mysqli_query($conn, $query);
        if ($_SESSION['role'] !== 'user') {
            logAction('Delete Book', 'tblbooks', $bookID, $_SESSION['userID'], "Deleted book: {$book['title']}");
        }
        mysqli_commit($conn);
        return true;
    } catch (Exception $e) {
        mysqli_rollback($conn);
        return false;
    }
}
function getBookStatuses($bookID) {
    global $conn;
    $bookID = (int)$bookID;
    $query = "SELECT status, statusDate, updatedBy
              FROM tblbookstatus
              WHERE bookID = ?
              ORDER BY statusDate DESC";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $bookID);
    $stmt->execute();
    $result = $stmt->get_result();
    $statuses = [];
    while ($row = $result->fetch_assoc()) {
        $statuses[] = [
            'status' => $row['status'] ?? 'Unknown',
            'statusDate' => $row['statusDate'] ?? 'N/A',
            'updatedBy' => $row['updatedBy'] ?? 'N/A'
        ];
    }
    $stmt->close();
    return $statuses;
}
function updateBookStatus($bookID, $status, $updatedBy) {
    global $conn;
    if ($_SESSION['role'] !== 'user') {
        return false;
    }
    
    $bookID = (int)$bookID;
    $status = mysqli_real_escape_string($conn, $status);
    $updatedBy = (int)$updatedBy;
    
    // Verify status is valid
    $validStatuses = ['Unread', 'In Progress', 'Read', 'On Loan', 'Damaged', 'Reserved'];
    if (!in_array($status, $validStatuses)) {
        return false;
    }
    
    // Verify user owns the book
    $query = "SELECT COUNT(*) FROM tblbook_ownership WHERE bookID = ? AND userID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ii', $bookID, $updatedBy);
    $stmt->execute();
    $stmt->bind_result($ownershipCount);
    $stmt->fetch();
    $stmt->close();
    
    if ($ownershipCount == 0) {
        return false;
    }
    
    $query = "SELECT COUNT(*) FROM tblbookstatus WHERE bookID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $bookID);
    $stmt->execute();
    $stmt->bind_result($statusCount);
    $stmt->fetch();
    $stmt->close();
    
    if ($statusCount > 0) {
        $query = "UPDATE tblbookstatus SET status = ?, statusDate = CURDATE(), updatedBy = ? WHERE bookID = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('sii', $status, $updatedBy, $bookID);
    } else {
        $query = "INSERT INTO tblbookstatus (bookID, status, statusDate, updatedBy) VALUES (?, ?, CURDATE(), ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('isi', $bookID, $status, $updatedBy);
    }
    
    $result = $stmt->execute();
    $stmt->close();
    return $result;
}

function deleteUserBook($bookID, $userID) {
    global $conn;
    $bookID = (int)$bookID;
    $userID = (int)$userID;

    // Check ownership
    $stmt = $conn->prepare("SELECT COUNT(*) FROM tblbook_ownership WHERE bookID = ? AND userID = ?");
    $stmt->bind_param('ii', $bookID, $userID);
    $stmt->execute();
    $stmt->bind_result($ownershipCount);
    $stmt->fetch();
    $stmt->close();

    if ($ownershipCount == 0) return "Error: You do not own this book.";

    // Count total owners
    $stmt = $conn->prepare("SELECT COUNT(*) FROM tblbook_ownership WHERE bookID = ?");
    $stmt->bind_param('i', $bookID);
    $stmt->execute();
    $stmt->bind_result($totalOwners);
    $stmt->fetch();
    $stmt->close();

    $book = getBookById($bookID);
    $title = $book['title'];

    mysqli_begin_transaction($conn);
    try {
        if ($totalOwners > 1) {
            // Remove only this user's ownership
            $stmt = $conn->prepare("DELETE FROM tblbook_ownership WHERE bookID = ? AND userID = ?");
            $stmt->bind_param('ii', $bookID, $userID);
            $stmt->execute();
            $stmt->close();

            // Remove user's ratings
            $stmt = $conn->prepare("DELETE FROM tblratings WHERE bookID = ? AND userID = ?");
            $stmt->bind_param('ii', $bookID, $userID);
            $stmt->execute();
            $stmt->close();

            // Remove user's reviews
            $stmt = $conn->prepare("DELETE FROM tblreviews WHERE bookID = ? AND userID = ?");
            $stmt->bind_param('ii', $bookID, $userID);
            $stmt->execute();
            $stmt->close();
        } else {
            // Last owner: delete book entirely
            $stmt = $conn->prepare("DELETE FROM tblbookstatus WHERE bookID = ?");
            $stmt->bind_param('i', $bookID);
            $stmt->execute();
            $stmt->close();

            $stmt = $conn->prepare("DELETE FROM tblratings WHERE bookID = ?");
            $stmt->bind_param('i', $bookID);
            $stmt->execute();
            $stmt->close();

            $stmt = $conn->prepare("DELETE FROM tblreviews WHERE bookID = ?");
            $stmt->bind_param('i', $bookID);
            $stmt->execute();
            $stmt->close();

            $stmt = $conn->prepare("DELETE FROM tblbook_ownership WHERE bookID = ?");
            $stmt->bind_param('i', $bookID);
            $stmt->execute();
            $stmt->close();

            $stmt = $conn->prepare("DELETE FROM tblbooks WHERE bookID = ?");
            $stmt->bind_param('i', $bookID);
            $stmt->execute();
            $stmt->close();
        }

        logAction('Delete Book Ownership', 'tblbook_ownership', $bookID, $userID, "User removed ownership of book: $title");
        mysqli_commit($conn);
        return true;
    } catch (Exception $e) {
        mysqli_rollback($conn);
        error_log("Delete book error: $e");
        return "Error: Transaction failed.";
    }
}

function rateBook($bookID, $userID, $rating) {
    global $conn;
    $bookID = (int)$bookID;
    $userID = (int)$userID;
    $rating = (int)$rating;

    // Check if user already rated
    $stmt = $conn->prepare("SELECT COUNT(*) FROM tblratings WHERE bookID = ? AND userID = ?");
    $stmt->bind_param('ii', $bookID, $userID);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    if ($count > 0) {
        // Update existing rating
        $stmt = $conn->prepare("UPDATE tblratings SET rating = ?, ratedDate = NOW() WHERE bookID = ? AND userID = ?");
        $stmt->bind_param('iii', $rating, $bookID, $userID);
    } else {
        // Insert new rating
        $stmt = $conn->prepare("INSERT INTO tblratings (userID, bookID, rating, ratedDate) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param('iii', $userID, $bookID, $rating);
    }

    $success = $stmt->execute();
    $stmt->close();

    if ($success) {
        // Log action only if the user is staff or admin
        if ($_SESSION['role'] === 'staff' || $_SESSION['role'] === 'admin') {
            logAction('Rate Book', 'tblratings', $bookID, $userID, "User rated book ID $bookID with $rating");
        }
        return true;
    }
    return false;
}

// Review functions
function addReview($bookID, $userID, $reviewText) {
    global $conn;
    $bookID = (int)$bookID;
    $userID = (int)$userID;
    $reviewText = mysqli_real_escape_string($conn, $reviewText);
    $query = "INSERT INTO tblreviews (bookID, userID, reviewText, reviewDate) 
              VALUES ($bookID, $userID, '$reviewText', CURDATE())";
    return mysqli_query($conn, $query);
}

function getReviews($bookID) {
    global $conn;
    $bookID = (int)$bookID;
    $query = "SELECT r.*, u.username FROM tblreviews r 
              JOIN tblusers u ON r.userID = u.userID 
              WHERE r.bookID = $bookID 
              ORDER BY r.reviewDate DESC";
    $result = mysqli_query($conn, $query);
    $reviews = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $reviews[] = $row;
    }
    return $reviews;
}

// Genre functions
function getGenreById($genreID) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM tblgenres WHERE genreID = ? AND isActive = 1");
    $stmt->bind_param('i', $genreID);
    $stmt->execute();
    $result = $stmt->get_result();
    $genre = $result->fetch_assoc();
    $stmt->close();
    return $genre ?: null;
}

function getGenreNameByID($genreID) {
    $genre = getGenreById($genreID);
    return $genre ? $genre['genreName'] : null;
}

function getGenresWithBookCount() {
    global $conn;
    $query = "SELECT g.*, COUNT(b.bookID) as bookCount 
              FROM tblgenres g 
              LEFT JOIN tblbooks b ON g.genreID = b.genreID 
              WHERE g.isActive = 1 
              GROUP BY g.genreID";
    $result = $conn->query($query);
    $genres = [];
    while ($row = $result->fetch_assoc()) {
        $genres[] = $row;
    }
    return $genres;
}

function getGenres() {
    global $conn;
    $query = "SELECT * FROM tblgenres WHERE isActive = 1 ORDER BY genreName ASC";
    $result = $conn->query($query);
    $genres = [];
    while ($row = $result->fetch_assoc()) {
        $genres[] = $row;
    }
    return $genres;
}

function updateGenre($genreID, $genreName, $description, $updatedBy) {
    global $conn;
    $genreName = mysqli_real_escape_string($conn, $genreName);
    $description = mysqli_real_escape_string($conn, $description);
    $updatedBy = (int)$updatedBy;

    // Validate genreName
    if (empty($genreName) || strlen($genreName) < 2 || strlen($genreName) > 50 || is_numeric($genreName)) {
        return false;
    }

    $stmt = $conn->prepare("UPDATE tblgenres SET genreName = ?, description = ?, createdBy = ? WHERE genreID = ? AND isActive = 1");
    $stmt->bind_param('ssii', $genreName, $description, $updatedBy, $genreID);
    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            if (!defined('PHPUNIT_TEST') && $_SESSION['role'] !== 'user') {
                logAction('Update Genre', 'tblgenres', $genreID, $updatedBy, "Updated genre: $genreName");
            }
            $stmt->close();
            return true;
        }
    }
    $stmt->close();
    return false;
}

function genreExists($genreName) {
    global $conn;
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM tblgenres WHERE LOWER(genreName) = LOWER(?) AND isActive = 1");
    $stmt->bind_param('s', $genreName);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    return $row['count'] > 0;
}

function addGenre($genreName, $description, $createdBy) {
    global $conn;
    $genreName = mysqli_real_escape_string($conn, $genreName);
    $description = mysqli_real_escape_string($conn, $description);
    $createdBy = (int)$createdBy;

    // Validate genreName
    if (empty($genreName) || strlen($genreName) < 2 || strlen($genreName) > 50 || is_numeric($genreName)) {
        return false;
    }

    // Check if genre exists but is inactive
    $stmt = $conn->prepare("SELECT genreID FROM tblgenres WHERE genreName = ? AND isActive = 0");
    if (!$stmt) {
        return false;
    }
    $stmt->bind_param('s', $genreName);
    if (!$stmt->execute()) {
        $stmt->close();
        return false;
    }
    $result = $stmt->get_result();
    if ($result && $result->num_rows > 0) {
        $genre = $result->fetch_assoc();
        $stmt = $conn->prepare("UPDATE tblgenres SET isActive = 1, description = ?, createdBy = ? WHERE genreID = ?");
        if (!$stmt) {
            return false;
        }
        $stmt->bind_param('sii', $description, $createdBy, $genre['genreID']);
        if ($stmt->execute()) {
            if (!defined('PHPUNIT_TEST') && $_SESSION['role'] !== 'user') {
                logAction('Reactivate Genre', 'tblgenres', $genre['genreID'], $createdBy, "Reactivated genre: $genreName");
            }
            $stmt->close();
            return true;
        }
        $stmt->close();
        return false;
    }
    $stmt->close();

    // Insert new genre
    $stmt = $conn->prepare("INSERT INTO tblgenres (genreName, description, createdDate, isActive, createdBy) VALUES (?, ?, CURDATE(), 1, ?)");
    if (!$stmt) {
        return false;
    }
    $stmt->bind_param('ssi', $genreName, $description, $createdBy);
    if ($stmt->execute()) {
        $genreID = $conn->insert_id;
        if (!defined('PHPUNIT_TEST') && $_SESSION['role'] !== 'user') {
            logAction('Add Genre', 'tblgenres', $genreID, $createdBy, "Added genre: $genreName");
        }
        $stmt->close();
        return true;
    }
    $stmt->close();
    return false;
}

function deleteGenre($genreID) {
    global $conn;
    $genreID = (int)$genreID;
    $query = "SELECT COUNT(*) FROM tblbooks WHERE genreID = $genreID";
    $result = mysqli_query($conn, $query);
    if (mysqli_fetch_row($result)[0] > 0) {
        return false; // Cannot delete genre with associated books
    }
    $query = "UPDATE tblgenres SET isActive = 0 WHERE genreID = $genreID";
    if (mysqli_query($conn, $query)) {
        if ($_SESSION['role'] !== 'user') {
            $genre = mysqli_fetch_assoc(mysqli_query($conn, "SELECT genreName FROM tblgenres WHERE genreID = $genreID"));
            logAction('Delete Genre', 'tblgenres', $genreID, $_SESSION['userID'], "Deleted genre: {$genre['genreName']}");
        }
        return true;
    }
    return false;
}

// Image upload function with GD fallback
function uploadImage($file) {
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return null;
    }
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
    if (!in_array($file['type'], $allowedTypes)) {
        return null;
    }
    $maxSize = 5 * 1024 * 1024; // 5MB
    if ($file['size'] > $maxSize) {
        return null;
    }

    $uploadDir = 'Uploads/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    $filename = uniqid() . '-' . basename($file['name']);
    $destination = $uploadDir . $filename;

    if (function_exists('imagecreatetruecolor')) {
        list($width, $height) = getimagesize($file['tmp_name']);
        $targetWidth = 200;
        $targetHeight = 300;
        $newImage = imagecreatetruecolor($targetWidth, $targetHeight);

        if ($file['type'] === 'image/png' || $file['type'] === 'image/gif') {
            imagealphablending($newImage, false);
            imagesavealpha($newImage, true);
            $transparent = imagecolorallocatealpha($newImage, 255, 255, 255, 127);
            imagefilledrectangle($newImage, 0, 0, $targetWidth, $targetHeight, $transparent);
        }

        switch ($file['type']) {
            case 'image/jpeg':
                $source = imagecreatefromjpeg($file['tmp_name']);
                imagecopyresampled($newImage, $source, 0, 0, 0, 0, $targetWidth, $targetHeight, $width, $height);
                imagejpeg($newImage, $destination, 80);
                break;
            case 'image/png':
                $source = imagecreatefrompng($file['tmp_name']);
                imagecopyresampled($newImage, $source, 0, 0, 0, 0, $targetWidth, $targetHeight, $width, $height);
                imagepng($newImage, $destination);
                break;
            case 'image/gif':
                $source = imagecreatefromgif($file['tmp_name']);
                imagecopyresampled($newImage, $source, 0, 0, 0, 0, $targetWidth, $targetHeight, $width, $height);
                imagegif($newImage, $destination);
                break;
        }
        imagedestroy($source);
        imagedestroy($newImage);
    } else {
        // Fallback if GD is not available
        if (!move_uploaded_file($file['tmp_name'], $destination)) {
            return null;
        }
    }

    return $destination;
}
function requestPasswordReset($email, $conn) {
    $stmt = $conn->prepare("SELECT userID FROM tblusers WHERE email = ? AND isActive = 1");
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($user = $result->fetch_assoc()) {
        $userID = $user['userID'];
        $token = bin2hex(random_bytes(32));
        $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
        $stmt = $conn->prepare("INSERT INTO tblpasswordresets (userID, token, expiryDate) VALUES (?, ?, ?)");
        $stmt->bind_param('iss', $userID, $token, $expiry);
        if ($stmt->execute()) {
            return ['token' => $token, 'userID' => $userID];
        }
    }
    return false;
}
function validateResetToken($token) {
    global $conn;
    $stmt = $conn->prepare("SELECT userID, expiryDate, used FROM tblpasswordresets WHERE token = ?");
    $stmt->bind_param('s', $token);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($reset = $result->fetch_assoc()) {
        if ($reset['used'] == 0 && strtotime($reset['expiryDate']) > time()) {
            return $reset['userID'];
        }
    }
    return false;
}

function resetPassword($userID, $password, $conn) {
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $conn->prepare("UPDATE tblusers SET password = ? WHERE userID = ?");
    $stmt->bind_param('si', $hashedPassword, $userID);
    if ($stmt->execute()) {
        $stmt = $conn->prepare("UPDATE tblpasswordresets SET used = 1 WHERE userID = ? AND used = 0");
        $stmt->bind_param('i', $userID);
        $stmt->execute();
        return true;
    }
    return false;
}
?>