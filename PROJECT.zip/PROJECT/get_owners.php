<?php
header('Content-Type: application/json');
session_start();
require_once 'functions.php';

if (!isset($_SESSION['userID']) || !isset($_SESSION['role'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$bookID = filter_input(INPUT_GET, 'bookID', FILTER_SANITIZE_NUMBER_INT);
if (!$bookID) {
    echo json_encode(['error' => 'Invalid book ID']);
    exit;
}

$owners = getBookOwners($bookID);
if ($owners === false) {
    echo json_encode(['error' => 'Failed to fetch owners']);
    exit;
}

echo json_encode(array_map(function($owner) {
    return [
        'username' => $owner['username'] ?? 'Unknown',
        'ownershipType' => $owner['ownershipType'] ?? 'N/A',
        'addedDate' => $owner['addedDate'] ?? 'N/A'
    ];
}, $owners));