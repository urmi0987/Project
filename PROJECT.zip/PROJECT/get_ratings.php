<?php
session_start();
require_once 'functions.php';

if (!isset($_SESSION['userID']) || !in_array($_SESSION['role'], ['staff', 'admin'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$bookID = filter_input(INPUT_GET, 'bookID', FILTER_SANITIZE_NUMBER_INT);
if (!$bookID) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Invalid book ID']);
    exit;
}

global $conn;
$stmt = $conn->prepare("
    SELECT r.userID, u.username, r.rating, r.ratedDate
    FROM tblratings r
    JOIN tblusers u ON r.userID = u.userID
    WHERE r.bookID = ?
    ORDER BY r.ratedDate DESC
");
$stmt->bind_param('i', $bookID);
$stmt->execute();
$result = $stmt->get_result();
$ratings = [];
while ($row = $result->fetch_assoc()) {
    $ratings[] = [
        'username' => $row['username'] ?? 'Unknown',
        'rating' => $row['rating'] ?? 'N/A',
        'ratedDate' => $row['ratedDate'] ?? 'N/A'
    ];
}
$stmt->close();

header('Content-Type: application/json');
echo json_encode($ratings);
exit;