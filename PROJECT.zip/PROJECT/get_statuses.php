<?php
require_once 'functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET' || !isset($_GET['bookID']) || !in_array($_SESSION['role'], ['staff', 'admin'])) {
    header('HTTP/1.1 403 Forbidden');
    echo json_encode(['error' => 'Unauthorized or invalid request']);
    exit;
}

$bookID = filter_input(INPUT_GET, 'bookID', FILTER_SANITIZE_NUMBER_INT);
if (!$bookID) {
    echo json_encode(['error' => 'Invalid book ID']);
    exit;
}

$statuses = getBookStatuses($bookID);
if (empty($statuses)) {
    echo json_encode(['error' => 'No statuses found']);
    exit;
}

echo json_encode($statuses);
exit;