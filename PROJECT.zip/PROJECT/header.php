<?php
ob_start(); // Start output buffering to capture all output before sending headers

// Start session only if it's not already active
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION['userID']) || !isset($_SESSION['role'])) {
    header('Location: welcome.php');
    exit;
}

// Normalize role to lowercase for consistency
$userRole = isset($_SESSION['role']) ? strtolower($_SESSION['role']) : '';

require_once 'functions.php';
$unreadCount = getUnreadNotificationCount($_SESSION['userID'], $userRole === 'user' ? 'user' : 'staff');

// Fetch notifications (to be displayed later in HTML)
$notifications = getNotifications($_SESSION['userID'], $userRole === 'user' ? 'user' : 'staff');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NewBees</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .fade-out {
            animation: fadeOut 3s forwards;
        }
        @keyframes fadeOut {
            0% { opacity: 1; }
            80% { opacity: 1; }
            100% { opacity: 0; display: none; }
        }
        .logo {
            height: 40px;
            margin-right: 8px;
        }
        .notification-bell {
            position: relative;
            cursor: pointer;
            font-size: 24px;
            color: #4b5563;
        }
        .notification-bell:hover {
            color: #1e40af;
        }
        .notification-count {
            position: absolute;
            top: -10px;
            right: -10px;
            background-color: #ef4444;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: bold;
        }
        .notification-panel {
            position: absolute;
            top: 50px;
            right: 20px;
            width: 300px;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            display: none;
            padding: 10px;
            max-height: 400px;
            overflow-y: auto;
        }
        .notification-item {
            padding: 8px;
            border-bottom: 1px solid #e5e7eb;
            cursor: pointer;
        }
        .notification-item:last-child {
            border-bottom: none;
        }
        .notification-item.unread {
            background-color: #e0f2fe;
            font-weight: bold;
        }
    </style>
</head>
<body class="bg-white">
    <nav class="bg-gradient-to-r from-sky-100 to-purple-100 p-4 shadow-lg">
        <div class="container mx-auto flex justify-between items-center">
            <a href="dashboard.php" class="flex items-center text-2xl font-bold text-indigo-700">
                <img src="Uploads/newbees_logo.jpg" alt="NewBees Logo" class="logo">
                NewBees
            </a>
            <div class="hidden md:flex space-x-4 items-center">
                <a href="dashboard.php" class="text-indigo-600 hover:text-indigo-800">Dashboard</a>
                <a href="profile.php" class="text-indigo-600 hover:text-indigo-800">Profile</a>
                <?php if ($userRole === 'admin' || $userRole === 'staff'): ?>
                    <a href="manage_users.php" class="text-indigo-600 hover:text-indigo-800">Manage Users</a>
                <?php endif; ?>
                <?php if ($userRole === 'admin'): ?>
                    <a href="manage_staff.php" class="text-indigo-600 hover:text-indigo-800">Manage Staff</a>
                <?php endif; ?>
                <?php if ($userRole === 'admin' || $userRole === 'staff'): ?>
                    <a href="manage_genres.php" class="text-indigo-600 hover:text-indigo-800">Manage Genres</a>
                    <a href="reports.php" class="text-indigo-600 hover:text-indigo-800">Reports</a>
                <?php endif; ?>
                <a href="logout.php" class="text-red-600 hover:text-red-800">Logout</a>
                <div class="notification-bell" onclick="toggleNotifications()">
                    🔔
                    <?php if ($unreadCount > 0): ?>
                        <span class="notification-count"><?php echo $unreadCount; ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <button class="md:hidden text-indigo-600" onclick="document.getElementById('mobile-menu').classList.toggle('hidden')">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path>
                </svg>
            </button>
        </div>
        <div id="mobile-menu" class="hidden md:hidden mt-4">
            <a href="dashboard.php" class="block text-indigo-600 hover:text-indigo-800 py-2">Dashboard</a>
            <a href="profile.php" class="block text-indigo-600 hover:text-indigo-800 py-2">Profile</a>
            <?php if ($userRole === 'admin' || $userRole === 'staff'): ?>
                <a href="manage_users.php" class="block text-indigo-600 hover:text-indigo-800 py-2">Manage Users</a>
            <?php endif; ?>
            <?php if ($userRole === 'admin'): ?>
                <a href="manage_staff.php" class="block text-indigo-600 hover:text-indigo-800 py-2">Manage Staff</a>
            <?php endif; ?>
            <?php if ($userRole === 'admin' || $userRole === 'staff'): ?>
                <a href="manage_genres.php" class="block text-indigo-600 hover:text-indigo-800 py-2">Manage Genres</a>
                <a href="reports.php" class="block text-indigo-600 hover:text-indigo-800 py-2">Reports</a>
            <?php endif; ?>
            <a href="logout.php" class="block text-red-600 hover:text-red-800 py-2">Logout</a>
        </div>
    </nav>
    <div id="notificationPanel" class="notification-panel">
        <?php
        if (empty($notifications)):
        ?>
            <p class="notification-item text-gray-600">No notifications.</p>
        <?php else: ?>
            <?php foreach ($notifications as $n): ?>
                <div class="notification-item <?php echo !$n['isRead'] ? 'unread' : ''; ?>" onclick="markAsRead(this)">
                    <span><?php echo htmlspecialchars($n['message']); ?></span>
                    <span class="text-sm text-gray-500 block"><?php echo htmlspecialchars($n['createdDate']); ?></span>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    <div class="container mx-auto p-4 min-h-screen">

    <script>
        function toggleNotifications() {
            const panel = document.getElementById('notificationPanel');
            panel.style.display = panel.style.display === 'block' ? 'none' : 'block';
        }

        function markAsRead(element) {
            const recipientID = <?php echo $_SESSION['userID']; ?>;
            const recipientType = '<?php echo $userRole === 'user' ? 'user' : 'staff'; ?>';

            // Send AJAX request to mark all notifications as read
            fetch('mark_notifications.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'recipientID=' + recipientID + '&recipientType=' + encodeURIComponent(recipientType)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update all notification items to remove 'unread' class
                    const items = document.querySelectorAll('.notification-item.unread');
                    items.forEach(item => item.classList.remove('unread'));
                    // Remove notification count
                    const countElement = document.querySelector('.notification-count');
                    if (countElement) {
                        countElement.remove();
                    }
                } else {
                    console.error('Failed to mark notifications as read:', data.error);
                }
            })
            .catch(error => console.error('Error:', error));
        }

        // Close notification panel when clicking outside
        document.addEventListener('click', function(event) {
            const panel = document.getElementById('notificationPanel');
            const bell = document.querySelector('.notification-bell');
            if (!panel.contains(event.target) && !bell.contains(event.target)) {
                panel.style.display = 'none';
            }
        });
    </script>
</body>
</html>