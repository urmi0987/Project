<?php
header('Location: welcome.php');
exit;
?>