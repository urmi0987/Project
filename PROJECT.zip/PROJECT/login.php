<?php
ob_start();
session_start();
require_once 'functions.php';

if (isset($_SESSION['userID'])) {
  header('Location: dashboard.php');
  exit;
}

$userError = '';
$staffError = '';
$resetLink = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['forgot_password'])) {
  $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
  $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
  $csrfToken = filter_input(INPUT_POST, 'csrf_token', FILTER_SANITIZE_STRING);
  $loginType = filter_input(INPUT_POST, 'login_type', FILTER_SANITIZE_STRING);

  if (validateCsrfToken($csrfToken)) {
    $user = $loginType === 'user' ? userLogin($email, $password, $conn) : staffLogin($email, $password);
    if ($user) {
      $_SESSION['userID'] = $user['userID'];
      $_SESSION['username'] = $user['username'];
      $_SESSION['role'] = $user['role'];
      $_SESSION['last_activity'] = time();
      header('Location: dashboard.php');
      exit;
    } else {
      if ($loginType === 'user') {
        $userError = 'Invalid email or password';
      } else {
        $staffError = 'Invalid email or password';
      }
    }
  } else {
    if ($loginType === 'user') {
      $userError = 'Invalid CSRF token';
    } else {
      $staffError = 'Invalid CSRF token';
    }
  }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['forgot_password'])) {
  $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
  $csrfToken = filter_input(INPUT_POST, 'csrf_token', FILTER_SANITIZE_STRING);
  if (validateCsrfToken($csrfToken)) {
    $resetData = requestPasswordReset($email);
    if ($resetData) {
      $resetLink = "http://localhost/PROJECT/reset_password.php?token=" . $resetData['token'];
    } else {
      $userError = 'Invalid email or error generating reset link.';
    }
  } else {
    $userError = 'Invalid CSRF token';
  }
}

$csrfToken = generateCsrfToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - NewBees</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    html, body {
      height: 100%;
      margin: 0;
    }
    body {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
    main {
      flex: 1 0 auto;
    }
    footer {
      flex-shrink: 0;
    }
    .tab {
      background-color: #f3f4f6;
      padding: 1rem;
      border-radius: 0.5rem 0.5rem 0 0;
      cursor: pointer;
      transition: background-color 0.3s;
    }
    .tab.active {
      background-color: #fff;
      font-weight: bold;
    }
    .tab-content {
      display: none;
      background-color: #fff;
      padding: 2rem;
      border-radius: 0 0 0.5rem 0.5rem;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    .tab-content.active {
      display: block;
    }
    .show-password {
      cursor: pointer;
      color: #4b5563;
    }
    .show-password:hover {
      color: #1e40af;
    }
  </style>
</head>
<body class="bg-gray-100 font-sans">
  <main class="flex-1 flex items-center justify-center p-4">
    <div class="bg-white p-8 rounded-lg shadow-lg max-w-2xl w-full">
      <h1 class="text-3xl font-bold text-indigo-700 text-center mb-8">Login to NewBees</h1>
      <?php if (isset($_GET['success'])): ?>
        <p class="text-green-500 text-center mb-4"><?php echo htmlspecialchars($_GET['success']); ?></p>
      <?php endif; ?>

      <!-- Tabs -->
      <div class="flex space-x-2 mb-4">
        <div class="tab active" onclick="showTab('user')">User Login</div>
        <div class="tab" onclick="showTab('staff')">Staff Login</div>
      </div>

      <!-- User Login -->
      <div id="user" class="tab-content active">
        <?php if ($userError): ?>
          <p class="text-red-500 text-center mb-4"><?php echo htmlspecialchars($userError); ?></p>
        <?php endif; ?>
        <?php if ($resetLink): ?>
          <p class="text-green-500 text-center mb-4">
            Copy this link to reset your password (expires in 1 hour): 
            <a href="<?php echo htmlspecialchars($resetLink); ?>" class="text-indigo-600 hover:underline break-all"><?php echo htmlspecialchars($resetLink); ?></a>
          </p>
        <?php endif; ?>
        <?php if (!isset($_GET['forgot']) && !$resetLink): ?>
          <form method="POST" class="space-y-4">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
            <input type="hidden" name="login_type" value="user">
            <div>
              <label class="block text-gray-700 mb-2 font-medium" for="user-email">Email</label>
              <input type="email" id="user-email" name="email" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
            </div>
            <div class="relative">
              <label class="block text-gray-700 mb-2 font-medium" for="user-password">Password</label>
              <input type="password" id="user-password" name="password" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
              <span class="show-password absolute right-3 top-9" onclick="togglePassword('user-password')">👁️</span>
            </div>
            <button type="submit" class="w-full bg-indigo-600 text-white p-2 rounded hover:bg-indigo-700 transition-colors duration-300">Login as User</button>
          </form>
          <p class="text-center mt-4"><a href="?forgot=1" class="text-indigo-600 hover:text-indigo-800">Forgot Password?</a></p>
          <div class="text-center mt-4">
            <p class="text-gray-700 mb-2">Don’t have an account?</p>
            <a href="signup.php" class="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 inline-block">Sign Up</a>
          </div>
        <?php elseif (!isset($_GET['forgot']) && $resetLink): ?>
          <p class="text-center mt-4"><a href="login.php" class="text-indigo-600 hover:text-indigo-800">Back to Login</a></p>
        <?php else: ?>
          <form method="POST" class="space-y-4" action="login.php">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
            <input type="hidden" name="forgot_password" value="1">
            <div>
              <label class="block text-gray-700 mb-2 font-medium" for="forgot-email">Email</label>
              <input type="email" id="forgot-email" name="email" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
            </div>
            <button type="submit" class="w-full bg-indigo-600 text-white p-2 rounded hover:bg-indigo-700 transition-colors duration-300">Generate Reset Link</button>
          </form>
          <p class="text-center mt-4"><a href="login.php" class="text-indigo-600 hover:text-indigo-800">Back to Login</a></p>
        <?php endif; ?>
        <p class="text-center mt-4">
          <a href="welcome.php" class="text-indigo-600 hover:text-indigo-800">Home</a> |
          <a href="terms.php" class="text-indigo-600 hover:text-indigo-800">Terms & Conditions</a> |
          <a href="privacy.php" class="text-indigo-600 hover:text-indigo-800">Privacy Policy</a>
        </p>
      </div>

      <!-- Staff Login -->
      <div id="staff" class="tab-content">
        <?php if ($staffError): ?>
          <p class="text-red-500 text-center mb-4"><?php echo htmlspecialchars($staffError); ?></p>
        <?php endif; ?>
        <form method="POST" class="space-y-4">
          <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
          <input type="hidden" name="login_type" value="staff">
          <div>
            <label class="block text-gray-700 mb-2 font-medium" for="staff-email">Email</label>
            <input type="email" id="staff-email" name="email" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
          </div>
          <div class="relative">
            <label class="block text-gray-700 mb-2 font-medium" for="staff-password">Password</label>
            <input type="password" id="staff-password" name="password" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
            <span class="show-password absolute right-3 top-9" onclick="togglePassword('staff-password')">👁️</span>
          </div>
          <button type="submit" class="w-full bg-indigo-600 text-white p-2 rounded hover:bg-indigo-700 transition-colors duration-300">Login as Staff</button>
        </form>
        <p class="text-center mt-4">
          <a href="welcome.php" class="text-indigo-600 hover:text-indigo-800">Home</a> |
          <a href="terms.php" class="text-indigo-600 hover:text-indigo-800">Terms & Conditions</a> |
          <a href="privacy.php" class="text-indigo-600 hover:text-indigo-800">Privacy Policy</a>
        </p>
      </div>
    </div>
  </main>

  <?php require_once 'footer.php'; ?>
  <?php ob_end_flush(); ?>

  <script>
    function showTab(tabId) {
      document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
      document.querySelector(`[onclick="showTab('${tabId}')"]`).classList.add('active');
      document.getElementById(tabId).classList.add('active');
    }

    function togglePassword(fieldId) {
      const passwordField = document.getElementById(fieldId);
      const type = passwordField.type === 'password' ? 'text' : 'password';
      passwordField.type = type;
    }
  </script>
</body>
</html>