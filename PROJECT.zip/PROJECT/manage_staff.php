<?php
require_once 'header.php';
require_once 'functions.php';

if ($_SESSION['role'] !== 'admin') {
    header('Location: dashboard.php');
    exit;
}

$staff = getStaff();
$notifications = getNotifications($_SESSION['userID'], 'staff');
$unreadCount = getUnreadNotificationCount($_SESSION['userID'], 'staff');
$csrfToken = generateCsrfToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !validateCsrfToken($_POST['csrf_token'])) {
        $error = 'Invalid CSRF token';
    } elseif (isset($_POST['add_staff'])) {
        $staffName = filter_input(INPUT_POST, 'staffName', FILTER_SANITIZE_STRING);
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
        $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
        $role = filter_input(INPUT_POST, 'role', FILTER_SANITIZE_STRING);
        $isAdmin = isset($_POST['isAdmin']) ? 1 : 0;
        
        if ($staffName && $email && $password && $role) {
            if (addStaff($staffName, $email, $password, $role, $isAdmin)) {
                $notification = "Staff '$staffName' added successfully!";
                addNotification($_SESSION['userID'], 'staff', $notification);
                header('Location: manage_staff.php?notification=' . urlencode($notification));
                exit;
            } else {
                $error = 'Failed to add staff. Email may already exist.';
            }
        } else {
            $error = 'All fields are required';
        }
    } elseif (isset($_POST['update_staff'])) {
        $staffID = filter_input(INPUT_POST, 'staffID', FILTER_SANITIZE_NUMBER_INT);
        $staffName = filter_input(INPUT_POST, 'staffName', FILTER_SANITIZE_STRING);
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
        $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
        $role = filter_input(INPUT_POST, 'role', FILTER_SANITIZE_STRING);
        $isAdmin = isset($_POST['isAdmin']) ? 1 : 0;
        
        if ($staffID && $staffName && $email && $role) {
            if (updateStaff($staffID, $staffName, $email, $password ?: null, $role, $isAdmin)) {
                $notification = "Staff '$staffName' updated successfully!";
                addNotification($_SESSION['userID'], 'staff', $notification);
                header('Location: manage_staff.php?notification=' . urlencode($notification));
                exit;
            } else {
                $error = 'Failed to update staff';
            }
        } else {
            $error = 'Name, email, and role are required';
        }
    } elseif (isset($_POST['delete_staff'])) {
        $staffID = filter_input(INPUT_POST, 'staffID', FILTER_SANITIZE_NUMBER_INT);
        if ($staffID) {
            if (deleteStaff($staffID)) {
                $notification = 'Staff deleted successfully!';
                addNotification($_SESSION['userID'], 'staff', $notification);
                header('Location: manage_staff.php?notification=' . urlencode($notification));
                exit;
            } else {
                $error = 'Cannot delete staff with associated genres';
            }
        } else {
            $error = 'Invalid staff ID';
        }
    }
}

$notification = filter_input(INPUT_GET, 'notification', FILTER_SANITIZE_STRING) ?? '';
?>

<style>
    .fade-out {
        animation: fadeOut 3s forwards;
    }
    @keyframes fadeOut {
        0% { opacity: 1; }
        80% { opacity: 1; }
        100% { opacity: 0; display: none; }
    }
</style>

<h2 class="text-3xl font-bold mb-6 text-indigo-700">Manage Staff</h2>
<!-- Breadcrumbs -->
<nav class="mb-4">
    <ol class="flex space-x-2 text-gray-600">
        <li><a href="dashboard.php" class="text-indigo-600 hover:text-indigo-800">Home</a></li>
        <li>/</li>
        <li>Manage Staff</li>
    </ol>
</nav>
<?php if (isset($error)): ?>
    <p class="text-red-500 mb-4 p-3 bg-red-100 rounded-lg fade-out"><?php echo htmlspecialchars($error); ?></p>
<?php endif; ?>
<?php if ($notification): ?>
    <p class="text-green-500 mb-4 p-3 bg-green-100 rounded-lg fade-out"><?php echo htmlspecialchars($notification); ?></p>
<?php endif; ?>

<div class="mb-6 bg-white p-6 rounded-lg shadow-lg">
    <h3 class="text-xl font-bold mb-4 text-indigo-700">Add New Staff</h3>
    <form method="POST" class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
        <div>
            <label class="block text-gray-700 mb-1">Name</label>
            <input type="text" name="staffName" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
        </div>
        <div>
            <label class="block text-gray-700 mb-1">Email</label>
            <input type="email" name="email" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
        </div>
        <div>
            <label class="block text-gray-700 mb-1">Password</label>
            <input type="password" name="password" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
        </div>
        <div>
            <label class="block text-gray-700 mb-1">Role</label>
            <input type="text" name="role" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
        </div>
        <div class="flex items-center">
            <input type="checkbox" name="isAdmin" class="mr-2">
            <label class="text-gray-700">Is Admin</label>
        </div>
        <div class="md:col-span-3">
            <button type="submit" name="add_staff" class="w-full md:w-auto bg-indigo-600 text-white p-2 rounded hover:bg-indigo-700 transition">Add Staff</button>
        </div>
    </form>
</div>

<div class="bg-white p-6 rounded-lg shadow-lg">
    <h3 class="text-xl font-bold mb-4 text-indigo-700">Staff List</h3>
    <div class="overflow-x-auto">
        <table class="w-full text-left">
            <thead>
                <tr class="bg-indigo-100">
                    <th class="p-3">Name</th>
                    <th class="p-3">Email</th>
                    <th class="p-3">Role</th>
                    <th class="p-3">Admin</th>
                    <th class="p-3">Hire Date</th>
                    <th class="p-3">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($staff as $staffMember): ?>
                    <?php if (isset($_GET['edit']) && $_GET['edit'] == $staffMember['staffID']): ?>
                        <tr class="border-b">
                            <td colspan="6" class="p-3">
                                <form method="POST" class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                                    <input type="hidden" name="staffID" value="<?php echo $staffMember['staffID']; ?>">
                                    <div>
                                        <label class="block text-gray-700 mb-1">Name</label>
                                        <input type="text" name="staffName" value="<?php echo htmlspecialchars($staffMember['staffName']); ?>" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
                                    </div>
                                    <div>
                                        <label class="block text-gray-700 mb-1">Email</label>
                                        <input type="email" name="email" value="<?php echo htmlspecialchars($staffMember['email']); ?>" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
                                    </div>
                                    <div>
                                        <label class="block text-gray-700 mb-1">Password (leave blank to keep current)</label>
                                        <input type="password" name="password" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                    </div>
                                    <div>
                                        <label class="block text-gray-700 mb-1">Role</label>
                                        <input type="text" name="role" value="<?php echo htmlspecialchars($staffMember['role']); ?>" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
                                    </div>
                                    <div class="flex items-center">
                                        <input type="checkbox" name="isAdmin" <?php echo $staffMember['isAdmin'] ? 'checked' : ''; ?> class="mr-2">
                                        <label class="text-gray-700">Is Admin</label>
                                    </div>
                                    <div class="flex space-x-2 items-end">
                                        <button type="submit" name="update_staff" class="bg-indigo-600 text-white p-2 rounded hover:bg-indigo-700 transition">Save</button>
                                        <a href="manage_staff.php" class="bg-gray-300 text-gray-700 p-2 rounded hover:bg-gray-400 transition">Cancel</a>
                                    </div>
                                </form>
                            </td>
                        </tr>
                    <?php else: ?>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="p-3"><?php echo htmlspecialchars($staffMember['staffName']); ?></td>
                            <td class="p-3"><?php echo htmlspecialchars($staffMember['email']); ?></td>
                            <td class="p-3"><?php echo htmlspecialchars($staffMember['role']); ?></td>
                            <td class="p-3"><?php echo $staffMember['isAdmin'] ? 'Yes' : 'No'; ?></td>
                            <td class="p-3"><?php echo htmlspecialchars($staffMember['hireDate']); ?></td>
                            <td class="p-3">
                                <a href="manage_staff.php?edit=<?php echo $staffMember['staffID']; ?>" class="text-indigo-600 hover:text-indigo-800 mr-2" title="Edit">
                                    <svg class="w-5 h-5 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                                </a>
                                <form method="POST" class="inline">
                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                                    <input type="hidden" name="staffID" value="<?php echo $staffMember['staffID']; ?>">
                                    <button type="submit" name="delete_staff" class="text-red-600 hover:text-red-800" title="Delete" onclick="return confirm('Are you sure you want to delete this staff member?')">
                                        <svg class="w-5 h-5 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5-4h4a1 1 0 011 1v1H9V4a1 1 0 011-1z"></path></svg>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

</div> <!-- Close the container div opened by header.php -->
<?php require_once 'footer.php'; ?>
</body>
</html>