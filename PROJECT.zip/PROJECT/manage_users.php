<?php
session_start();
ob_start(); // Start output buffering (already present, kept for consistency)

// Ensure session variables are set (similar to header.php)
if (!isset($_SESSION['userID']) || !isset($_SESSION['role'])) {
    header('Location: welcome.php');
    exit;
}

// Debug full session data
error_log("Session data in manage_users.php: " . print_r($_SESSION, true));

// Normalize role to lowercase to avoid case sensitivity issues
$userRole = isset($_SESSION['role']) ? strtolower($_SESSION['role']) : '';

// Allow admin and staff access
if (!($userRole === 'admin' || $userRole === 'staff')) {
    error_log("Access denied for role: " . $userRole);
    header('Location: dashboard.php');
    exit;
}

require_once 'functions.php';
require_once 'header.php'; // Header should open container div

$users = getUsers($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_user'])) {
        $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
        $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);

        if ($username && $email && $password) {
            if (signup($username, $email, $password, $conn)) {
                header('Location: manage_users.php');
                exit;
            } else {
                $error = 'Failed to add user. Username or email may already exist.';
            }
        } else {
            $error = 'All fields are required';
        }
    } elseif (isset($_POST['update_user'])) {
        $userID = filter_input(INPUT_POST, 'userID', FILTER_SANITIZE_NUMBER_INT);
        $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
        $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);

        if ($userID && $username && $email) {
            if (updateUser($userID, $username, $email, $conn, $password ?: null)) {
                header('Location: manage_users.php');
                exit;
            } else {
                $error = 'Failed to update user';
            }
        } else {
            $error = 'Username and email are required';
        }
    } elseif (isset($_POST['delete_user'])) {
        $userID = filter_input(INPUT_POST, 'userID', FILTER_SANITIZE_NUMBER_INT);
        if ($userID) {
            if (deleteUser($userID, $conn)) {
                header('Location: manage_users.php');
                exit;
            } else {
                $error = 'Failed to delete user. User may have associated books.';
            }
        } else {
            $error = 'Invalid user ID';
        }
    }
}
?>

<h2 class="text-3xl font-bold mb-6 text-indigo-700">Manage Users</h2>

<!-- Breadcrumbs -->
<nav class="mb-4">
  <ol class="flex space-x-2 text-gray-600">
    <li><a href="dashboard.php" class="text-indigo-600 hover:text-indigo-800">Home</a></li>
    <li>/</li>
    <li>Manage Users</li>
  </ol>
</nav>

<?php if (isset($error)): ?>
    <p class="text-red-500 mb-4 p-3 bg-red-100 rounded-lg"><?php echo htmlspecialchars($error); ?></p>
<?php endif; ?>

<div class="mb-6 bg-white p-6 rounded-lg shadow-lg">
    <h3 class="text-xl font-bold mb-4 text-indigo-700">Add New User</h3>
    <form method="POST" class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
            <label class="block text-gray-700 mb-1">Username</label>
            <input type="text" name="username" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
        </div>
        <div>
            <label class="block text-gray-700 mb-1">Email</label>
            <input type="email" name="email" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
        </div>
        <div>
            <label class="block text-gray-700 mb-1">Password</label>
            <input type="password" name="password" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
        </div>
        <div class="md:col-span-3">
            <button type="submit" name="add_user" class="w-full md:w-auto bg-indigo-600 text-white p-2 rounded hover:bg-indigo-700 transition">Add User</button>
        </div>
    </form>
</div>

<div class="bg-white p-6 rounded-lg shadow-lg">
    <h3 class="text-xl font-bold mb-4 text-indigo-700">User List</h3>
    <div class="overflow-x-auto">
        <table class="w-full text-left">
            <thead>
                <tr class="bg-indigo-100">
                    <th class="p-3">Username</th>
                    <th class="p-3">Email</th>
                    <th class="p-3">Join Date</th>
                    <th class="p-3">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <?php if (isset($_GET['edit']) && $_GET['edit'] == $user['userID']): ?>
                        <tr class="border-b">
                            <td colspan="4" class="p-3">
                                <form method="POST" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                                    <input type="hidden" name="userID" value="<?php echo $user['userID']; ?>">
                                    <div>
                                        <label class="block text-gray-700 mb-1">Username</label>
                                        <input type="text" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
                                    </div>
                                    <div>
                                        <label class="block text-gray-700 mb-1">Email</label>
                                        <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
                                    </div>
                                    <div>
                                        <label class="block text-gray-700 mb-1">Password (leave blank to keep current)</label>
                                        <input type="password" name="password" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                    </div>
                                    <div class="flex space-x-2 items-end">
                                        <button type="submit" name="update_user" class="bg-indigo-600 text-white p-2 rounded hover:bg-indigo-700 transition">Save</button>
                                        <a href="manage_users.php" class="bg-gray-300 text-gray-700 p-2 rounded hover:bg-gray-400 transition">Cancel</a>
                                    </div>
                                </form>
                            </td>
                        </tr>
                    <?php else: ?>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="p-3"><?php echo htmlspecialchars($user['username']); ?></td>
                            <td class="p-3"><?php echo htmlspecialchars($user['email']); ?></td>
                            <td class="p-3"><?php echo htmlspecialchars($user['joinDate']); ?></td>
                            <td class="p-3">
                                <a href="manage_users.php?edit=<?php echo $user['userID']; ?>" class="text-indigo-600 hover:text-indigo-800 mr-2" title="Edit">
                                    <svg class="w-5 h-5 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                                    </svg>
                                </a>
                                <form method="POST" class="inline">
                                    <input type="hidden" name="userID" value="<?php echo $user['userID']; ?>">
                                    <button type="submit" name="delete_user" class="text-red-600 hover:text-red-800" title="Delete" onclick="return confirm('Are you sure you want to delete this user?')">
                                        <svg class="w-5 h-5 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5-4h4a1 1 0 011 1v1H9V4a1 1 0 011-1z"/>
                                        </svg>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

</div> <!-- Close main container opened by header.php -->

<?php
ob_end_flush(); // End output buffering and send the output
require_once 'footer.php'; // Footer presumably closes body and html
?>