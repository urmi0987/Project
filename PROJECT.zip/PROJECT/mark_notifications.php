<?php
require_once 'functions.php';

header('Content-Type: application/json');

$recipientID = filter_input(INPUT_POST, 'recipientID', FILTER_SANITIZE_NUMBER_INT);
$recipientType = filter_input(INPUT_POST, 'recipientType', FILTER_SANITIZE_STRING);

if ($recipientID && in_array($recipientType, ['user', 'staff'])) {
  if (markNotificationsAsRead($recipientID, $recipientType)) {
    echo json_encode(['success' => true]);
    exit;
  }
}

echo json_encode(['success' => false]);
?>