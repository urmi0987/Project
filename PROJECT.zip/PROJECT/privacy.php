<?php
ob_start();
session_start();
require_once 'functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Privacy Policy - NewBees</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    html, body {
      height: 100%;
      margin: 0;
    }
    body {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
    main {
      flex: 1 0 auto;
    }
    footer {
      flex-shrink: 0;
    }
    .privacy-section {
      max-width: 800px;
      margin: 0 auto;
    }
  </style>
</head>
<body class="bg-gray-100 font-sans">
  <main class="flex-1 flex items-center justify-center p-4">
    <div class="bg-white p-6 rounded-lg shadow-lg max-w-3xl w-full privacy-section">
      <h1 class="text-3xl font-bold text-center text-indigo-600 mb-6">Privacy Policy</h1>
      <p class="text-sm text-gray-500 text-center mb-8">Last Updated: June 3, 2025</p>

      <h2 class="text-xl font-semibold text-indigo-600 mt-6 mb-4">1. Introduction</h2>
      <p class="text-gray-700 mb-4">NewBees Ltd. ("we", "us") operates the Book Collection Tracker website ("Service") at newbees.com. This Privacy Policy explains how we collect, use, and protect your personal data under the General Data Protection Regulation (GDPR).</p>

      <h2 class="text-xl font-semibold text-indigo-600 mt-6 mb-4">2. Data We Collect</h2>
      <p class="text-gray-700 mb-4">We collect:</p>
      <ul class="list-disc ml-6 text-gray-700 mb-4">
        <li><strong>Account Data</strong>: Username, email, password (hashed).</li>
        <li><strong>Usage Data</strong>: Book collection details, ratings, reviews.</li>
        <li><strong>Technical Data</strong>: IP address, browser type, device info.</li>
      </ul>

      <h2 class="text-xl font-semibold text-indigo-600 mt-6 mb-4">3. How We Use Your Data</h2>
      <p class="text-gray-700 mb-4">We use data to:</p>
      <ul class="list-disc ml-6 text-gray-700 mb-4">
        <li>Provide and improve the Service.</li>
        <li>Manage accounts and authenticate users.</li>
        <li>Send notifications (e.g., password resets).</li>
        <li>Analyze usage for service enhancements.</li>
      </ul>

      <h2 class="text-xl font-semibold text-indigo-600 mt-6 mb-4">4. Lawful Basis</h2>
      <p class="text-gray-700 mb-4">We process data based on:</p>
      <ul class="list-disc ml-6 text-gray-700 mb-4">
        <li><strong>Consent</strong>: When you sign up or submit data.</li>
        <li><strong>Contract</strong>: To deliver the Service.</li>
        <li><strong>Legitimate Interests</strong>: For analytics and security.</li>
      </ul>

      <h2 class="text-xl font-semibold text-indigo-600 mt-6 mb-4">5. Data Sharing</h2>
      <p class="text-gray-700 mb-4">We do not share data except:</p>
      <ul class="list-disc ml-6 text-gray-700 mb-4">
        <li>With your consent (e.g., email services).</li>
        <li>To comply with legal obligations.</li>
        <li>With service providers (e.g., SMTP for emails) under GDPR-compliant agreements.</li>
      </ul>

      <h2 class="text-xl font-semibold text-indigo-600 mt-6 mb-4">6. Data Retention</h2>
      <p class="text-gray-700 mb-4">We retain data until you delete your account or as required by law. Password reset tokens expire after 1 hour.</p>

      <h2 class="text-xl font-semibold text-indigo-600 mt-6 mb-4">7. Your GDPR Rights</h2>
      <p class="text-gray-700 mb-4">You have the right to:</p>
      <ul class="list-disc ml-6 text-gray-700 mb-4">
        <li>Access your data.</li>
        <li>Rectify inaccurate data.</li>
        <li>Erase data ("right to be forgotten").</li>
        <li>Restrict processing.</li>
        <li>Data portability.</li>
        <li>Object to processing.</li>
        <li>Withdraw consent.</li>
      </ul>
      <p class="text-gray-700 mb-4">Contact <a href="mailto:support@newbees.com" class="text-indigo-600 hover:underline">support@newbees.com</a> to exercise these rights.</p>

      <h2 class="text-xl font-semibold text-indigo-600 mt-6 mb-4">8. Security</h2>
      <p class="text-gray-700 mb-4">We use encryption (e.g., hashed passwords) and secure protocols to protect data. However, no system is fully secure.</p>

      <h2 class="text-xl font-semibold text-indigo-600 mt-6 mb-4">9. Cookies</h2>
      <p class="text-gray-700 mb-4">We use session cookies for authentication. No tracking cookies are used. You can manage cookies via browser settings.</p>

      <h2 class="text-xl font-semibold text-indigo-600 mt-6 mb-4">10. Changes to Policy</h2>
      <p class="text-gray-700 mb-4">We may update this Policy and notify users via email or in-app. Continued use implies acceptance.</p>

      <h2 class="text-xl font-semibold text-indigo-600 mt-6 mb-4">11. Contact Us</h2>
      <p class="text-gray-700 mb-4">Email <a href="mailto:support@newbees.com" class="text-indigo-600 hover:underline">support@newbees.com</a> or write to NewBees Ltd., Copenhagen, Denmark</p>

      <p class="text-center mt-8">
        <a href="welcome.php" class="text-indigo-600 hover:text-indigo-800">Back to Home</a>
      </p>
    </div>
  </main>
  <?php require_once 'footer.php'; ?>
  <?php ob_end_flush(); ?>
</body>
</html>