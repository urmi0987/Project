<?php
require_once 'header.php';
require_once 'functions.php';

$userID = $_SESSION['userID'];
$user = null;
if ($_SESSION['role'] === 'user') {
  $query = "SELECT * FROM tblusers WHERE userID = " . (int)$userID;
  $result = mysqli_query($conn, $query);
  $user = mysqli_fetch_assoc($result);
} else {
  $query = "SELECT * FROM tblstaff WHERE staffID = " . (int)$userID;
  $result = mysqli_query($conn, $query);
  $user = mysqli_fetch_assoc($result);
}

$notification = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (isset($_POST['update_profile'])) {
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
    
    if ($username && $email) {
      if ($_SESSION['role'] === 'user') {
        if (updateUser($userID, $username, $email, $password ?: null)) {
          $notification = 'Profile updated successfully!';
          header('Location: profile.php?notification=' . urlencode($notification));
          exit;
        } else {
          $error = 'Failed to update profile';
        }
      } else {
        if (updateStaff($userID, $username, $email, $password ?: null, $user['role'], $user['isAdmin'])) {
          $notification = 'Profile updated successfully!';
          header('Location: profile.php?notification=' . urlencode($notification));
          exit;
        } else {
          $error = 'Failed to update profile';
        }
      }
    } else {
      $error = 'Username and email are required';
    }
  } elseif (isset($_POST['delete_account']) && $_SESSION['role'] === 'user') {
    if (deleteUser($userID)) {
      header('Location: logout.php');
      exit;
    } else {
      $error = 'Failed to delete account';
    }
  }
}

$notification = filter_input(INPUT_GET, 'notification', FILTER_SANITIZE_STRING) ?? $notification;
?>
<h2 class="text-3xl font-bold mb-6 text-indigo-700">Profile</h2>
<?php if ($notification): ?>
  <div id="notification" class="mb-4 p-3 bg-green-100 text-green-700 rounded-lg flex justify-between items-center">
    <span><?php echo htmlspecialchars($notification); ?></span>
    <button onclick="document.getElementById('notification').remove()" class="text-green-700 hover:text-green-900">✕</button>
  </div>
<?php endif; ?>
<?php if (isset($error)): ?>
  <div class="mb-4 p-3 bg-red-100 text-red-700 rounded-lg"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>
<div class="bg-white p-6 rounded-lg shadow-lg">
  <form method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-4">
    <div>
      <label class="block text-gray-700 mb-1">Username</label>
      <input type="text" name="username" value="<?php echo htmlspecialchars($user['username'] ?? $user['staffName']); ?>" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
    </div>
    <div>
      <label class="block text-gray-700 mb-1">Email</label>
      <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
    </div>
    <div class="md:col-span-2">
      <label class="block text-gray-700 mb-1">New Password (leave blank to keep current)</label>
      <input type="password" name="password" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500">
    </div>
    <div class="md:col-span-2 flex space-x-4">
      <button type="submit" name="update_profile" class="bg-indigo-600 text-white p-2 rounded hover:bg-indigo-700 transition">Update Profile</button>
      <?php if ($_SESSION['role'] === 'user'): ?>
        <button type="submit" name="delete_account" onclick="return confirm('Are you sure you want to delete your account? This cannot be undone.')" class="bg-red-600 text-white p-2 rounded hover:bg-red-700 transition">Delete Account</button>
      <?php endif; ?>
    </div>
  </form>
</div>
</div>
<?php require_once 'footer.php'; ?>
</body>
</html>