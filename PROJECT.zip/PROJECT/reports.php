<?php
require_once 'header.php';
require_once 'functions.php';

if ($_SESSION['role'] === 'user') {
  header('Location: dashboard.php?error=' . urlencode('Access denied'));
  exit;
}

$search = filter_input(INPUT_GET, 'search', FILTER_SANITIZE_STRING) ?? '';
$genreID = filter_input(INPUT_GET, 'genreID', FILTER_SANITIZE_NUMBER_INT) ?? '';
$status = filter_input(INPUT_GET, 'status', FILTER_SANITIZE_STRING) ?? '';
$dateFrom = filter_input(INPUT_GET, 'dateFrom', FILTER_SANITIZE_STRING) ?? '';
$dateTo = filter_input(INPUT_GET, 'dateTo', FILTER_SANITIZE_STRING) ?? '';
$reportType = filter_input(INPUT_GET, 'reportType', FILTER_SANITIZE_STRING) ?? 'books';

$books = ($reportType === 'books') ? getBooks(null, $search, $genreID, $status) : [];
$users = ($reportType === 'users') ? getUsers() : [];
$auditLogs = ($reportType === 'audit') ? getAuditLogs($dateFrom, $dateTo) : [];
$genres = getGenres();

// Filter Books by date
if ($dateFrom && $dateTo && $reportType === 'books') {
  $books = array_filter($books, function($book) use ($dateFrom, $dateTo) {
    return $book['addedDate'] >= $dateFrom && $book['addedDate'] <= $dateTo;
  });
}

// Filter Users by joinDate
if ($dateFrom && $dateTo && $reportType === 'users') {
  $users = array_filter($users, function($user) use ($dateFrom, $dateTo) {
    return $user['joinDate'] >= $dateFrom && $user['joinDate'] <= $dateTo;
  });
}

// Enhance books with owner data
if ($reportType === 'books') {
  foreach ($books as &$book) {
    $owners = getBookOwners($book['bookID']);
    $book['owners'] = $owners ? array_column($owners, 'username') : [];
    $book['owner_list'] = $owners ? implode(', ', array_column($owners, 'username')) : 'None';
  }
  unset($book);
}

$notification = filter_input(INPUT_GET, 'notification', FILTER_SANITIZE_STRING) ?? '';
$csrfToken = generateCsrfToken();

function getAuditLogs($dateFrom = '', $dateTo = '') {
  global $conn;
  $query = "SELECT al.*, s.staffName FROM tblauditlogs al 
            JOIN tblstaff s ON al.staffID = s.staffID";
  if ($dateFrom && $dateTo) {
    $dateFrom = mysqli_real_escape_string($conn, $dateFrom);
    $dateTo = mysqli_real_escape_string($conn, $dateTo);
    $query .= " WHERE al.actionDate BETWEEN '$dateFrom' AND '$dateTo 23:59:59'";
  }
  $query .= " ORDER BY al.actionDate DESC";
  $result = mysqli_query($conn, $query);
  $logs = [];
  while ($row = mysqli_fetch_assoc($result)) {
    $logs[] = $row;
  }
  return $logs;
}
?>
<h2 class="text-3xl font-bold mb-6 text-indigo-700">Reports</h2>
<!-- Breadcrumbs -->
<nav class="mb-4">
  <ol class="flex space-x-2 text-gray-600">
    <li><a href="dashboard.php" class="text-indigo-600 hover:text-indigo-800">Home</a></li>
    <li>/</li>
    <li>Reports</li>
  </ol>
</nav>
<?php if ($notification): ?>
  <div id="notification" class="mb-4 p-3 bg-green-100 text-green-700 rounded-lg flex justify-between items-center fade-out">
    <span><?php echo htmlspecialchars($notification); ?></span>
    <button onclick="document.getElementById('notification').remove()" class="text-green-700 hover:text-green-900">✕</button>
  </div>
<?php endif; ?>
<div class="mb-6 bg-white p-6 rounded-lg shadow-lg">
  <form method="GET" class="flex flex-wrap gap-4 items-end">
    <div>
      <label class="block text-gray-700 mb-1">Report Type</label>
      <select name="reportType" class="p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" onchange="this.form.submit()">
        <option value="books" <?php echo $reportType === 'books' ? 'selected' : ''; ?>>Books</option>
        <option value="users" <?php echo $reportType === 'users' ? 'selected' : ''; ?>>Users</option>
        <option value="audit" <?php echo $reportType === 'audit' ? 'selected' : ''; ?>>Audit Logs</option>
      </select>
    </div>
    <?php if ($reportType === 'books'): ?>
      <div class="flex-1">
        <label class="block text-gray-700 mb-1">Search Books</label>
        <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search by title or author..." class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500">
      </div>
      <div>
        <label class="block text-gray-700 mb-1">Genre</label>
        <select name="genreID" class="p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500">
          <option value="">All Genres</option>
          <?php foreach ($genres as $genre): ?>
            <option value="<?php echo $genre['genreID']; ?>" <?php echo ($genreID === (string)$genre['genreID']) ? 'selected' : ''; ?>>
              <?php echo htmlspecialchars($genre['genreName']); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
    <?php endif; ?>
    <div>
      <label class="block text-gray-700 mb-1">Date From</label>
      <input type="date" name="dateFrom" value="<?php echo htmlspecialchars($dateFrom); ?>" class="p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500">
    </div>
    <div>
      <label class="block text-gray-700 mb-1">Date To</label>
      <input type="date" name="dateTo" value="<?php echo htmlspecialchars($dateTo); ?>" class="p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500">
    </div>
    <button type="submit" class="bg-indigo-600 text-white p-2 rounded hover:bg-indigo-700 transition">Filter</button>
  </form>
</div>

<div class="mb-6">
  <button id="exportCsv" class="bg-green-600 text-white p-2 rounded hover:bg-green-700 transition">Export to CSV</button>
</div>

<div class="bg-white p-6 rounded-lg shadow-lg">
  <?php if ($reportType === 'books'): ?>
    <h3 class="text-xl font-bold mb-4 text-indigo-700">Book Report</h3>
    <?php if (empty($books)): ?>
      <p class="text-gray-600">No books found.</p>
    <?php else: ?>
      <div class="overflow-x-auto">
        <table class="w-full table-auto">
          <thead>
            <tr class="bg-indigo-100">
              <th class="p-2 text-left">Title</th>
              <th class="p-2 text-left">Author</th>
              <th class="p-2 text-left">Genre</th>
              <th class="p-2 text-left">Owner</th>
              <th class="p-2 text-left">Added Date</th>
              <th class="p-2 text-left">View Ratings</th>
              <th class="p-2 text-left">View Status</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($books as $book): ?>
              <tr class="border-b">
                <td class="p-2"><?php echo htmlspecialchars($book['title']); ?></td>
                <td class="p-2"><?php echo htmlspecialchars($book['author']); ?></td>
                <td class="p-2"><?php echo htmlspecialchars($book['genreName'] ?? 'Unknown'); ?></td>
                <td class="p-2">
                  <?php if (!empty($book['owners'])): ?>
                    <a href="#" class="text-indigo-600 hover:text-indigo-800 view-owners" data-book-id="<?php echo htmlspecialchars($book['bookID']); ?>">
                      View Owners (<?php echo count($book['owners']); ?>)
                    </a>
                  <?php else: ?>
                    None
                  <?php endif; ?>
                </td>
                <td class="p-2"><?php echo htmlspecialchars($book['addedDate']); ?></td>
                <td class="p-2">
                  <a href="#" class="text-indigo-600 hover:text-indigo-800 view-ratings" data-book-id="<?php echo htmlspecialchars($book['bookID']); ?>">View Ratings</a>
                </td>
                <td class="p-2">
                  <a href="#" class="text-indigo-600 hover:text-indigo-800 view-statuses" data-book-id="<?php echo htmlspecialchars($book['bookID']); ?>">View Statuses</a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  <?php elseif ($reportType === 'users'): ?>
    <h3 class="text-xl font-bold mb-4 text-indigo-700">User Report</h3>
    <?php if (empty($users)): ?>
      <p class="text-gray-600">No users found.</p>
    <?php else: ?>
      <div class="overflow-x-auto">
        <table class="w-full table-auto">
          <thead>
            <tr class="bg-indigo-100">
              <th class="p-2 text-left">Username</th>
              <th class="p-2 text-left">Email</th>
              <th class="p-2 text-left">Join Date</th>
              <th class="p-2 text-left">Last Login</th>
              <th class="p-2 text-left">Books Owned</th>
              <th class="p-2 text-left">Active</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($users as $user): ?>
              <tr class="border-b">
                <td class="p-2"><?php echo htmlspecialchars($user['username']); ?></td>
                <td class="p-2"><?php echo htmlspecialchars($user['email']); ?></td>
                <td class="p-2"><?php echo htmlspecialchars($user['joinDate']); ?></td>
                <td class="p-2"><?php echo htmlspecialchars($user['lastLogin'] ?? 'Never'); ?></td>
                <td class="p-2"><?php echo htmlspecialchars($user['bookCount'] ?? 0); ?></td>
                <td class="p-2"><?php echo ($user['isActive'] ?? false) ? 'Yes' : 'No'; ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  <?php elseif ($reportType === 'audit'): ?>
    <h3 class="text-xl font-bold mb-4 text-indigo-700">Audit Log Report</h3>
    <?php if (empty($auditLogs)): ?>
      <p class="text-gray-600">No audit logs found.</p>
    <?php else: ?>
      <div class="overflow-x-auto">
        <table class="w-full table-auto">
          <thead>
            <tr class="bg-indigo-100">
              <th class="p-2 text-left">Action</th>
              <th class="p-2 text-left">Table</th>
              <th class="p-2 text-left">Record ID</th>
              <th class="p-2 text-left">Staff</th>
              <th class="p-2 text-left">Date</th>
              <th class="p-2 text-left">Details</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($auditLogs as $log): ?>
              <tr class="border-b">
                <td class="p-2"><?php echo htmlspecialchars($log['action']); ?></td>
                <td class="p-2"><?php echo htmlspecialchars($log['tableName']); ?></td>
                <td class="p-2"><?php echo $log['recordID']; ?></td>
                <td class="p-2"><?php echo htmlspecialchars($log['staffName']); ?></td>
                <td class="p-2"><?php echo htmlspecialchars($log['actionDate']); ?></td>
                <td class="p-2"><?php echo htmlspecialchars($log['details'] ?? 'N/A'); ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  <?php endif; ?>
</div>

<!-- Modal for Owners -->
<div id="ownersModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden flex items-center justify-center z-50">
  <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
    <h3 class="text-xl font-bold mb-4 text-indigo-700">Book Owners</h3>
    <ul id="ownersList" class="mb-4"></ul>
    <button id="closeOwnersModal" class="bg-indigo-600 text-white p-2 rounded hover:bg-indigo-700 transition">Close</button>
  </div>
</div>

<!-- Modal for Ratings -->
<div id="ratingsModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden flex items-center justify-center z-50">
  <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
    <h3 class="text-xl font-bold mb-4 text-indigo-700">Book Ratings</h3>
    <ul id="ratingsList" class="mb-4"></ul>
    <button id="closeRatingsModal" class="bg-indigo-600 text-white p-2 rounded hover:bg-indigo-700 transition">Close</button>
  </div>
</div>

<!-- Modal for Statuses -->
<div id="statusesModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden flex items-center justify-center z-50">
  <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
    <h3 class="text-xl font-bold mb-4 text-indigo-700">Book Statuses</h3>
    <ul id="statusesList" class="mb-4"></ul>
    <button id="closeStatusesModal" class="bg-indigo-600 text-white p-2 rounded hover:bg-indigo-700 transition">Close</button>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/PapaParse/5.4.1/papaparse.min.js"></script>
<script>
document.getElementById('exportCsv').addEventListener('click', function() {
  let data = [];
  <?php if ($reportType === 'books'): ?>
    data = <?php echo json_encode(array_map(function($book) {
      return [
        'Title' => $book['title'] ?? 'N/A',
        'Author' => $book['author'] ?? 'N/A',
        'Genre' => $book['genreName'] ?? 'Unknown',
        'Owner' => $book['owner_list'] ?? 'None',
        'Added Date' => $book['addedDate'] ?? 'N/A'
      ];
    }, $books)); ?>;
  <?php elseif ($reportType === 'users'): ?>
    data = <?php echo json_encode(array_map(function($user) {
      return [
        'Username' => $user['username'] ?? 'N/A',
        'Email' => $user['email'] ?? 'N/A',
        'Join Date' => $user['joinDate'] ?? 'N/A',
        'Last Login' => $user['lastLogin'] ?? 'Never',
        'Books Owned' => $user['bookCount'] ?? 0,
        'Active' => ($user['isActive'] ?? false) ? 'Yes' : 'No'
      ];
    }, $users)); ?>;
  <?php elseif ($reportType === 'audit'): ?>
    data = <?php echo json_encode(array_map(function($log) {
      return [
        'Action' => $log['action'] ?? 'N/A',
        'Table' => $log['tableName'] ?? 'N/A',
        'Record ID' => $log['recordID'] ?? 'N/A',
        'Staff' => $log['staffName'] ?? 'N/A',
        'Date' => $log['actionDate'] ?? 'N/A',
        'Details' => $log['details'] ?? 'N/A'
      ];
    }, $auditLogs)); ?>;
  <?php endif; ?>
  
  if (data.length === 0) {
    alert('No data to export.');
    return;
  }

  const csv = Papa.unparse(data);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = '<?php echo $reportType; ?>_report_<?php echo date('Ymd'); ?>.csv';
  link.click();
});

document.querySelectorAll('.view-owners').forEach(link => {
  link.addEventListener('click', function(e) {
    e.preventDefault();
    const bookID = this.getAttribute('data-book-id');
    fetch(`get_owners.php?bookID=${bookID}`)
      .then(response => response.json())
      .then(data => {
        const ownersList = document.getElementById('ownersList');
        ownersList.innerHTML = '';
        if (data.error) {
          ownersList.innerHTML = `<li class="text-red-600">${data.error}</li>`;
        } else if (data.length === 0) {
          ownersList.innerHTML = '<li class="text-gray-600">No owners found.</li>';
        } else {
          data.forEach(owner => {
            const li = document.createElement('li');
            li.className = 'text-gray-700';
            li.textContent = `${owner.username} (${owner.ownershipType}, Added: ${owner.addedDate})`;
            ownersList.appendChild(li);
          });
        }
        document.getElementById('ownersModal').classList.remove('hidden');
      })
      .catch(error => {
        const ownersList = document.getElementById('ownersList');
        ownersList.innerHTML = `<li class="text-red-600">Error fetching owners: ${error.message}</li>`;
        document.getElementById('ownersModal').classList.remove('hidden');
      });
  });
});

document.querySelectorAll('.view-ratings').forEach(link => {
  link.addEventListener('click', function(e) {
    e.preventDefault();
    const bookID = this.getAttribute('data-book-id');
    fetch(`get_ratings.php?bookID=${bookID}`)
      .then(response => response.json())
      .then(data => {
        const ratingsList = document.getElementById('ratingsList');
        ratingsList.innerHTML = '';
        if (data.error) {
          ratingsList.innerHTML = `<li class="text-red-600">${data.error}</li>`;
        } else if (data.length === 0) {
          ratingsList.innerHTML = '<li class="text-gray-600">No ratings found.</li>';
        } else {
          data.forEach(rating => {
            const li = document.createElement('li');
            li.className = 'text-gray-700';
            li.textContent = `${rating.username}: ${rating.rating} stars (Rated: ${rating.ratedDate})`;
            ratingsList.appendChild(li);
          });
        }
        document.getElementById('ratingsModal').classList.remove('hidden');
      })
      .catch(error => {
        const ratingsList = document.getElementById('ratingsList');
        ratingsList.innerHTML = `<li class="text-red-600">Error fetching ratings: ${error.message}</li>`;
        document.getElementById('ratingsModal').classList.remove('hidden');
      });
  });
});

document.querySelectorAll('.view-statuses').forEach(link => {
  link.addEventListener('click', function(e) {
    e.preventDefault();
    const bookID = this.getAttribute('data-book-id');
    fetch(`get_statuses.php?bookID=${bookID}`)
      .then(response => response.json())
      .then(data => {
        const statusesList = document.getElementById('statusesList');
        statusesList.innerHTML = '';
        if (data.error) {
          statusesList.innerHTML = `<li class="text-red-600">${data.error}</li>`;
        } else if (data.length === 0) {
          statusesList.innerHTML = '<li class="text-gray-600">No statuses found.</li>';
        } else {
          data.forEach(status => {
            const li = document.createElement('li');
            li.className = 'text-gray-700';
            li.textContent = `Status: ${status.status} (Updated: ${status.statusDate}, By User ID: ${status.updatedBy})`;
            statusesList.appendChild(li);
          });
        }
        document.getElementById('statusesModal').classList.remove('hidden');
      })
      .catch(error => {
        const statusesList = document.getElementById('statusesList');
        statusesList.innerHTML = `<li class="text-red-600">Error fetching statuses: ${error.message}</li>`;
        document.getElementById('statusesModal').classList.remove('hidden');
      });
  });
});

document.getElementById('closeOwnersModal').addEventListener('click', function() {
  document.getElementById('ownersModal').classList.add('hidden');
});

document.getElementById('closeRatingsModal').addEventListener('click', function() {
  document.getElementById('ratingsModal').classList.add('hidden');
});

document.getElementById('closeStatusesModal').addEventListener('click', function() {
  document.getElementById('statusesModal').classList.add('hidden');
});
</script>

<style>
.fade-out {
  animation: fadeOut 5s forwards;
}
@keyframes fadeOut {
  0% { opacity: 1; }
  80% { opacity: 1; }
  100% { opacity: 0; display: none; }
}
</style>
<?php require_once 'footer.php'; ?>