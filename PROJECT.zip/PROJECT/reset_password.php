<?php
ob_start();
session_start();
require_once 'functions.php';

$error = '';
$success = '';
$token = filter_input(INPUT_GET, 'token', FILTER_SANITIZE_STRING);
$userID = $token ? validateResetToken($token) : false;

if (!$userID) {
    $error = 'Invalid or expired reset link.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $userID) {
    $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
    $confirmPassword = filter_input(INPUT_POST, 'confirm_password', FILTER_SANITIZE_STRING);
    $csrfToken = filter_input(INPUT_POST, 'csrf_token', FILTER_SANITIZE_STRING);

    if (validateCsrfToken($csrfToken)) {
        if ($password === $confirmPassword && strlen($password) >= 8) {
            if (resetPassword($userID, $password, $conn)) {
                $success = 'Password reset successfully. <a href="login.php" class="text-indigo-600 hover:underline">Login now</a>.';
            } else {
                $error = 'Error resetting password. Try again.';
            }
        } else {
            $error = 'Passwords do not match or are too short (minimum 8 characters).';
        }
    } else {
        $error = 'Invalid CSRF token.';
    }
}

$csrfToken = generateCsrfToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reset Password - NewBees</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    html, body {
      height: 100%;
      margin: 0;
    }
    body {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
    main {
      flex: 1 0 auto;
    }
    footer {
      flex-shrink: 0;
    }
    .show-password {
      cursor: pointer;
      color: #4b5563;
    }
    .show-password:hover {
      color: #1e40af;
    }
  </style>
</head>
<body class="bg-gray-100 font-sans">
  <main class="flex-1 flex items-center justify-center p-4">
    <div class="bg-white p-8 rounded-lg shadow-lg max-w-md w-full">
      <h1 class="text-3xl font-bold text-indigo-700 text-center mb-8">Reset Password</h1>
      <?php if ($error): ?>
        <p class="text-red-500 text-center mb-4"><?php echo htmlspecialchars($error); ?></p>
      <?php endif; ?>
      <?php if ($success): ?>
        <p class="text-green-500 text-center mb-4"><?php echo $success; ?></p>
      <?php else: ?>
        <form method="POST" class="space-y-4">
          <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
          <div class="relative">
            <label class="block text-gray-700 mb-2 font-medium" for="password">New Password</label>
            <input type="password" id="password" name="password" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required minlength="8">
            <span class="show-password absolute right-3 top-9" onclick="togglePassword('password')">👁️</span>
          </div>
          <div class="relative">
            <label class="block text-gray-700 mb-2 font-medium" for="confirm-password">Confirm Password</label>
            <input type="password" id="confirm-password" name="confirm_password" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required minlength="8">
            <span class="show-password absolute right-3 top-9" onclick="togglePassword('confirm-password')">👁️</span>
          </div>
          <button type="submit" class="w-full bg-indigo-600 text-white p-2 rounded hover:bg-indigo-700 transition-colors duration-300">Reset Password</button>
        </form>
      <?php endif; ?>
      <p class="text-center mt-4"><a href="login.php" class="text-indigo-600 hover:text-indigo-800">Back to Login</a></p>
    </div>
  </main>
  <?php require_once 'footer.php'; ?>
  <?php ob_end_flush(); ?>
  <script>
    function togglePassword(fieldId) {
      const passwordField = document.getElementById(fieldId);
      const type = passwordField.type === 'password' ? 'text' : 'password';
      passwordField.type = type;
    }
  </script>
</body>
</html>