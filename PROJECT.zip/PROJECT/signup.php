<?php
ob_start(); // Start output buffering
session_start();
require_once 'functions.php';

if (isset($_SESSION['userID'])) {
  header('Location: dashboard.php');
  exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
  $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
  $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
  $terms = isset($_POST['terms']);
  $csrfToken = filter_input(INPUT_POST, 'csrf_token', FILTER_SANITIZE_STRING);

  if (!validateCsrfToken($csrfToken)) {
    $error = 'Invalid CSRF token';
  } elseif (!$terms) {
    $error = 'You must agree to the Terms and Conditions';
  } else {
    if (signup($username, $email, $password, $conn)) {
      header('Location: login.php?success=' . urlencode('Sign up successful! Please log in.'));
      exit();
    } else {
      $error = 'Username or email already exists';
    }
  }
}
$csrfToken = generateCsrfToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="viewport" content="width=device-width, initial-scale=1.0">
<meta charset="UTF-8">
  <title>Sign Up - NewBees</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    html, body {
      height: 100%;
      margin: 0;
    }
    body {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
    main {
      flex: 1 0 auto;
    }
    footer {
      flex-shrink: 0;
    }
  </style>
</head>
<body class="bg-gray-100 font-sans">
  <main class="flex-1 flex items-center justify-center p-4">
    <div class="bg-white p-6 rounded-lg shadow-lg max-w-md w-full">
      <h1 class="text-3xl font-bold text-center text-indigo-600 mb-6">Sign Up for NewBees</h3>
      <?php if ($error): ?>
        <p class="text-red-500 text-center mb-4"><?php echo htmlspecialchars($error); ?></p>
      <?php endif; ?>
      <?php if (isset($_GET['success'])): ?>
        <p class="text-green-500 text-center mb-4"><?php echo htmlspecialchars($_GET['success']); ?></p>
      <?php endif; ?>
      <form method="POST" class="space-y-4">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
        <div>
          <label for="username" class="block text-sm font-medium text-gray-700 mb-2">Username</label>
          <input type="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500" id="username" name="username" type="text" required>
        </div>
        <div>
          <label for="email" class="block text-sm font-medium text-gray-700 mb-2">Email</label>
          <input type="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500" id="email" name="email" type="email" required>
        </div>
        <div>
          <label for="password" class="block text-sm font-medium text-gray-700 mb-2">Password</label>
          <input class="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500" id="password" name="password" type="password" required>
        </div>
        <div class="flex items-center">
          <input type="checkbox" id="terms" name="terms" class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
          <label for="terms" class="ml-2 block text-sm font-medium text-gray-700">
            I agree to the <a href="terms.php" class="text-indigo-600 hover:underline">Terms & Conditions</a> and <a href="privacy.php" class="text-indigo-600 hover:underline">Privacy Policy</a>
          </label>
        </div>
        <button type="submit" class="w-full bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition-colors duration-300">Sign Up</button>
      </form>
      <p class="text-center mt-4">
        <a href="welcome.php" class="text-indigo-600 hover:text-indigo-800">Back to Home</a>
      </p>
    </div>
  </main>

  <?php require_once 'footer.php'; ?>
  <?php ob_end_flush(); ?>
</body>
</html>