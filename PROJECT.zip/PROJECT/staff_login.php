<?php
session_start();
require_once 'functions.php';

if (isset($_SESSION['userID'])) {
  header('Location: dashboard.php');
  exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
  $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
  $csrfToken = filter_input(INPUT_POST, 'csrf_token', FILTER_SANITIZE_STRING);

  if (validateCsrfToken($csrfToken)) {
    $user = staffLogin($email, $password);
    if ($user) {
      $_SESSION['userID'] = $user['userID'];
      $_SESSION['username'] = $user['username'];
      $_SESSION['role'] = $user['role'];
      $_SESSION['last_activity'] = time();
      header('Location: dashboard.php');
      exit;
    } else {
      $error = 'Invalid email or password';
    }
  } else {
    $error = 'Invalid CSRF token';
  }
}
$csrfToken = generateCsrfToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Staff Login - NewBees</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans">
  <div class="container mx-auto p-4 max-w-md">
    <h1 class="text-3xl font-bold text-indigo-700 text-center mb-6">Staff Login</h1>
    <?php if ($error): ?>
      <p class="text-red-500 text-center mb-4"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>
    <form method="POST" class="bg-white p-6 rounded-lg shadow-lg">
      <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
      <div class="mb-4">
        <label class="block text-gray-700 mb-2" for="email">Email</label>
        <input type="email" id="email" name="email" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
      </div>
      <div class="mb-4">
        <label class="block text-gray-700 mb-2" for="password">Password</label>
        <input type="password" id="password" name="password" class="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-indigo-500" required>
      </div>
      <button type="submit" class="w-full bg-indigo-600 text-white p-2 rounded hover:bg-indigo-700">Login</button>
    </form>
    <p class="text-center mt-4"><a href="welcome.php" class="text-indigo-600 hover:text-indigo-800">Back to Welcome</a></p>
  </div>
<?php require_once 'footer.php'; ?>
</body>
</html>