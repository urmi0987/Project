<?php
ob_start();
session_start();
require_once 'functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="viewport" content="width=device-width, initial-scale=1.0">
<meta charset="UTF-8">
  <title>Terms & Conditions - NewBees</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    html, body {
      height: 100%;
      margin: 0;
    }
    body {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
  main {
      flex: 1 0 auto;
    }
    footer {
      flex-shrink: 0;
    }
  .terms-section {
      max-width: 800px;
      margin: 0 auto;
    }
  </style>
</head>
<body class="bg-gray-100 font-sans">
  <main class="flex-1 flex items-center justify-center p-4">
    <div class="bg-white p-6 rounded-lg shadow-lg max-w-3xl w-full terms-section">
      <h1 class="text-3xl font-bold text-center text-indigo-600 mb-6">Terms & Conditions</h1>
      <p class="text-sm text-gray-500 text-center mb-8">Last Updated: June 3, 2025</p>

      <h2 class="text-xl font-semibold text-indigo-600 mt-6 mb-4">1. Introduction</h2>
      <p class="text-gray-700 mb-4">Welcome to NewBees, operated by NewBees Ltd. These Terms and Conditions govern your use of the Book Collection Tracker website ("Service") at newbees.com. By accessing or using the Service, you agree to these Terms. If you disagree, please do not use the Service.</p>

      <h2 class="text-xl font-semibold text-indigo-600 mt-6 mb-4">2. Eligibility</h2>
      <p class="text-gray-700 mb-4">You must be at least 16 years old to use the Service. By registering, you confirm you meet this requirement.</p>

      <h2 class="text-xl font-semibold text-indigo-600 mt-6 mb-4">3. Account Responsibilities</h2>
      <p class="text-gray-700 mb-4">You are responsible for maintaining the confidentiality of your account credentials. Notify us at <a href="mailto:support@newbees.com" class="text-indigo-600 hover:underline">support@newbees.com</a> if you suspect unauthorized use.</p>

      <h2 class="text-xl font-semibold text-indigo-600 mt-6 mb-4">4. Data Processing (GDPR)</h2>
      <p class="text-gray-700 mb-4">We process personal data under the General Data Protection Regulation (GDPR):</p>
      <ul class="list-disc ml-6 text-gray-700 mb-4">
        <li><strong>Data Collected</strong>: Username, email, book data, ratings, reviews, IP address.</li>
        <li><strong>Purpose</strong>: Account management, service delivery, analytics.</li>
        <li><strong>Lawful Basis</strong>: Consent (signup) and contract (service).</li>
        <li><strong>Rights</strong>: Access, rectify, erase, restrict, data portability, withdraw consent. Contact <a href="mailto:support@newbees.com" class="text-indigo-600 hover:underline">support@newbees.com</a>.</li>
        <li><strong>Retention</strong>: Until account deletion or legal requirement.</li>
        <li><strong>Sharing</strong>: Only with legal obligations or consent (e.g., email services).</li>
      </ul>
      <p class="text-gray-700 mb-4">See our <a href="privacy.php" class="text-indigo-600 hover:underline">Privacy Policy</a> for details.</p>

      <h2 class="text-xl font-semibold text-indigo-600 mt-6 mb-4">5. User Content</h2>
      <p class="text-gray-700 mb-4">You own your reviews and ratings but grant us a non-exclusive, royalty-free license to display them. Do not submit illegal content.</p>

      <h2 class="text-xl font-semibold text-indigo-600 mt-6 mb-4">6. Prohibited Actions</h2>
      <p class="text-gray-700 mb-4">You may not:</p>
      <ul class="list-disc ml-6 text-gray-700 mb-4">
        <li>Use the Service illegally.</li>
        <li>Upload malicious content.</li>
        <li>Spam or harass users.</li>
        <li>Access unauthorized areas.</li>
      </ul>

      <h2 class="text-xl font-semibold text-indigo-600 mt-6 mb-4">7. Termination</h2>
      <p class="text-gray-700 mb-4">We may suspend accounts for violations. You may delete your account via <a href="mailto:support@newbees.com" class="text-indigo-600 hover:underline">support@newbees.com</a>.</p>

      <h2 class="text-xl font-semibold text-indigo-600 mt-6 mb-4">8. Limitation of Liability</h2>
      <p class="text-gray-700 mb-4">NewBees Ltd. is not liable for indirect damages. We do not guarantee error-free service.</p>

      <h2 class="text-xl font-semibold text-indigo-600 mt-6 mb-4">9. Changes to Terms</h2>
      <p class="text-gray-700 mb-4">We may update Terms and notify users via email or in-app. Continued use implies acceptance.</p>

      <h2 class="text-xl font-semibold text-indigo-600 mt-6 mb-4">10. Governing Law</h2>
      <p class="text-gray-700 mb-4">Governed by DK law. Disputes resolved in DK courts.</p>

      <h2 class="text-xl font-semibold text-indigo-600 mt-6 mb-4">11. Contact Us</h2>
      <p class="text-gray-700 mb-4">Email <a href="mailto:support@newbees.com" class="text-indigo-600 hover:underline">support@newbees.com</a> or write to NewBees Ltd., Copenhagen, Denmark.</p>

      <p class="text-center mt-8">
        <a href="welcome.php" class="text-indigo-600 hover:text-indigo-800">Back to Home</a>
      </p>
    </div>
  </main>
  <?php require_once 'footer.php'; ?>
  <?php ob_end_flush(); ?>
</body>
</html>