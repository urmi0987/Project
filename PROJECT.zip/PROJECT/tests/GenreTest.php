<?php
use PHPUnit\Framework\TestCase;
require_once 'functions.php';

class GenreTest extends TestCase {
    private $conn;

    protected function setUp(): void {
        $this->conn = new mysqli('localhost', 'root', '', 'book_collection_tracker');
        $this->conn->query("TRUNCATE TABLE tblbooks");
        $this->conn->query("TRUNCATE TABLE tblgenres");
        $this->conn->query("INSERT INTO tblgenres (genreID, genreName, description, createdDate, isActive, createdBy) VALUES 
            (3, 'Action', 'Action-packed stories', CURDATE(), 1, 1),
            (2, 'Comedy', 'Humorous literature', CURDATE(), 1, 1),
            (1, 'Fiction', 'Fictional literature', CURDATE(), 1, 1)");
    }

    public function testGetGenreByIdValid() {
        $genre = getGenreById(1);
        $this->assertEquals('Fiction', $genre['genreName']);
    }

    public function testGetGenreByIdInvalid() {
        $genre = getGenreById(999);
        $this->assertNull($genre);
    }

    public function testAddGenreEmptyName() {
        $result = addGenre('', 'Empty genre', 1);
        $this->assertFalse($result);
    }

    public function testAddGenreNameTooShort() {
        $result = addGenre('A', 'Too short', 1);
        $this->assertFalse($result);
    }

    public function testAddGenreTooLong() {
        $result = addGenre(str_repeat('a', 51), 'Too long', 1);
        $this->assertFalse($result);
    }

    public function testAddGenreNumeric() {
        $result = addGenre('123', 'Numeric genre', 1);
        $this->assertFalse($result);
    }

    public function testAddGenreMinBoundary() {
        $result = addGenre('Ab', 'Valid genre', 1);
        $this->assertTrue($result);
    }

    public function testAddGenreMaxBoundary() {
        $result = addGenre(str_repeat('a', 50), 'Valid max length', 1);
        $this->assertTrue($result);
    }

    public function testAddGenreDuplicate() {
        addGenre('Fiction', 'Duplicate', 1);
        $result = addGenre('Fiction', 'Another duplicate', 1);
        $this->assertFalse($result);
    }

    public function testUpdateGenreValid() {
        $result = updateGenre(1, 'NewFiction', 'Updated fiction', 1);
        $this->assertTrue($result);
        $genre = getGenreById(1);
        $this->assertEquals('NewFiction', $genre['genreName']);
    }

    public function testUpdateGenreInvalidName() {
        $result = updateGenre(1, '', 'Empty name', 1);
        $this->assertFalse($result);
    }

    public function testDeleteGenreNoBooks() {
        $result = deleteGenre(2);
        $this->assertTrue($result);
        $genre = getGenreById(2);
        $this->assertNull($genre);
    }

    public function testDeleteGenreWithBooks() {
        $this->conn->query("INSERT INTO tblbooks (title, author, genreID, addedDate) VALUES ('Test Book', 'Author', 1, CURDATE())");
        $result = deleteGenre(1);
        $this->assertFalse($result);
    }

    public function testGetGenresWithBookCount() {
        $this->conn->query("INSERT INTO tblbooks (title, author, genreID, addedDate) VALUES ('Test Book', 'Author', 1, CURDATE())");
        $genres = getGenresWithBookCount();
        $fiction = array_filter($genres, fn($g) => $g['genreID'] == 1);
        $fiction = reset($fiction);
        $this->assertEquals(1, $fiction['bookCount']);
    }

    public function testGetGenres() {
        $genres = getGenres();
        $this->assertCount(3, $genres);
        $this->assertEquals('Action', $genres[0]['genreName']);
    }

    protected function tearDown(): void {
        $this->conn->close();
    }
}
?>