<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
#define('PHPUNIT_TESTING', true);
use PHPUnit\Framework\TestCase;
require_once dirname(__DIR__) . '/functions.php';

class LoginTest extends TestCase {
    private $conn;

    protected function setUp(): void {
        $this->conn = mysqli_connect("localhost", "root", "", "book_collection_tracker");
        $this->assertNotFalse($this->conn, 'Database connection failed');
        // Get userID for 'hawa'
        $result = mysqli_query($this->conn, "SELECT userID FROM tblusers WHERE username = 'hawa'");
        $userID = null;
        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $userID = $row['userID'];
        }
        if ($userID) {
            mysqli_query($this->conn, "DELETE FROM tblbookstatus WHERE updatedBy = $userID");
            mysqli_query($this->conn, "DELETE FROM tblbook_ownership WHERE userID = $userID");
            mysqli_query($this->conn, "DELETE FROM tblpasswordresets WHERE userID = $userID");
            mysqli_query($this->conn, "DELETE FROM tblusers WHERE userID = $userID");
        }
        // Insert test user
        $hashed = password_hash("Hawa123!", PASSWORD_BCRYPT);
        $insertResult = mysqli_query($this->conn, "INSERT INTO tblusers (username, email, password, joinDate) 
                            VALUES ('hawa', 'hawa@example.com', '$hashed', CURDATE())");
        $this->assertTrue($insertResult, 'Failed to insert test user: ' . mysqli_error($this->conn));
    }

    public function testLoginNormal() {
        $result = userLogin("hawa@example.com", "Hawa123!", $this->conn);
        $this->assertIsArray($result);
        $this->assertEquals("hawa", $result['username']);
    }

    public function testLoginInvalidPassword() {
        $result = userLogin("hawa@example.com", "WrongPass", $this->conn);
        $this->assertFalse($result);
    }

    protected function tearDown(): void {
        $result = mysqli_query($this->conn, "SELECT userID FROM tblusers WHERE username = 'hawa'");
        $userID = null;
        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $userID = $row['userID'];
        }
        if ($userID) {
            mysqli_query($this->conn, "DELETE FROM tblbookstatus WHERE updatedBy = $userID");
            mysqli_query($this->conn, "DELETE FROM tblbook_ownership WHERE userID = $userID");
            mysqli_query($this->conn, "DELETE FROM tblpasswordresets WHERE userID = $userID");
            mysqli_query($this->conn, "DELETE FROM tblusers WHERE userID = $userID");
        }
        mysqli_close($this->conn);
    }
}