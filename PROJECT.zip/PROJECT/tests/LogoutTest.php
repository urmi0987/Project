<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
use PHPUnit\Framework\TestCase;

class LogoutTest extends TestCase {
    protected function setUp(): void {
        // Ensure no active session before each test
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }
    }

    public function testLogoutClearsSession() {
        session_start();
        $_SESSION['userID'] = 2;
        ob_start();
        include dirname(__DIR__) . '/logout.php';
        ob_end_clean();
        $this->assertEmpty($_SESSION);
    }

    public function testLogoutNoSession() {
        session_start();
        session_destroy();
        ob_start();
        include dirname(__DIR__) . '/logout.php';
        ob_end_clean();
        $this->assertEmpty($_SESSION);
    }

    protected function tearDown(): void {
        // Clean up session
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }
    }
}