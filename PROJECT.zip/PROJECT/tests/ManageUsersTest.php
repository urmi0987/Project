<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
#define('PHPUNIT_TESTING', true);
use PHPUnit\Framework\TestCase;
require_once dirname(__DIR__) . '/functions.php';

class ManageUsersTest extends TestCase {
    private $conn;

    protected function setUp(): void {
        $this->conn = mysqli_connect("localhost", "root", "", "book_collection_tracker");
        $this->assertNotFalse($this->conn, 'Database connection failed');
        // Mock session for logAction
        $_SESSION['role'] = 'admin';
        $_SESSION['userID'] = 1;
        // Clean up test user
        $result = mysqli_query($this->conn, "SELECT userID FROM tblusers WHERE userID = 4");
        $userID = null;
        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $userID = $row['userID'];
        }
        if ($userID) {
            mysqli_query($this->conn, "DELETE FROM tblbookstatus WHERE updatedBy = $userID");
            mysqli_query($this->conn, "DELETE FROM tblbook_ownership WHERE userID = $userID");
            mysqli_query($this->conn, "DELETE FROM tblpasswordresets WHERE userID = $userID");
            mysqli_query($this->conn, "DELETE FROM tblusers WHERE userID = $userID");
        }
        // Insert test user
        $insertResult = mysqli_query($this->conn, "INSERT INTO tblusers (userID, username, email, password, joinDate) 
                            VALUES (4, 'maya', 'maya@example.com', 'hashed', CURDATE())");
        $this->assertTrue($insertResult, 'Failed to insert test user: ' . mysqli_error($this->conn));
    }

    public function testUpdateUserNormal() {
        $result = updateUser(4, "newmaya", "newmaya@example.com", $this->conn, null);
        $this->assertTrue($result);
        $row = mysqli_fetch_assoc(mysqli_query($this->conn, "SELECT username FROM tblusers WHERE userID = 4"));
        $this->assertEquals("newmaya", $row['username']);
    }

    public function testDeleteUserNormal() {
        mysqli_query($this->conn, "DELETE FROM tblbookstatus WHERE updatedBy = 4");
        mysqli_query($this->conn, "DELETE FROM tblbook_ownership WHERE userID = 4");
        $result = deleteUser(4, $this->conn);
        $this->assertTrue($result);
        $row = mysqli_fetch_assoc(mysqli_query($this->conn, "SELECT username FROM tblusers WHERE userID = 4"));
        $this->assertEmpty($row);
    }

    protected function tearDown(): void {
        // Clean up session
        $_SESSION = [];
        $result = mysqli_query($this->conn, "SELECT userID FROM tblusers WHERE userID = 4");
        $userID = null;
        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $userID = $row['userID'];
        }
        if ($userID) {
            mysqli_query($this->conn, "DELETE FROM tblbookstatus WHERE updatedBy = $userID");
            mysqli_query($this->conn, "DELETE FROM tblbook_ownership WHERE userID = $userID");
            mysqli_query($this->conn, "DELETE FROM tblpasswordresets WHERE userID = $userID");
            mysqli_query($this->conn, "DELETE FROM tblusers WHERE userID = $userID");
        }
        mysqli_close($this->conn);
    }
}