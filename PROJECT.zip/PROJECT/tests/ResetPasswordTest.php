<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
#define('PHPUNIT_TESTING', true);
use PHPUnit\Framework\TestCase;
require_once dirname(__DIR__) . '/functions.php';

class ResetPasswordTest extends TestCase {
    private $conn;

    protected function setUp(): void {
        $this->conn = mysqli_connect("localhost", "root", "", "book_collection_tracker");
        $this->assertNotFalse($this->conn, 'Database connection failed');
        // Clean up test user
        $result = mysqli_query($this->conn, "SELECT userID FROM tblusers WHERE userID = 5");
        $userID = null;
        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $userID = $row['userID'];
        }
        if ($userID) {
            mysqli_query($this->conn, "DELETE FROM tblbookstatus WHERE updatedBy = $userID");
            mysqli_query($this->conn, "DELETE FROM tblbook_ownership WHERE userID = $userID");
            mysqli_query($this->conn, "DELETE FROM tblpasswordresets WHERE userID = $userID");
            mysqli_query($this->conn, "DELETE FROM tblusers WHERE userID = $userID");
        }
        // Insert test user
        $insertResult = mysqli_query($this->conn, "INSERT INTO tblusers (userID, username, email, password, joinDate) 
                            VALUES (5, 'testreset', 'reset@example.com', 'hashed', CURDATE())");
        $this->assertTrue($insertResult, 'Failed to insert test user: ' . mysqli_error($this->conn));
    }

    public function testRequestPasswordResetValidEmail() {
        $result = requestPasswordReset("reset@example.com", $this->conn);
        $this->assertIsArray($result);
        $this->assertArrayHasKey('token', $result);
    }

    public function testResetPasswordNormal() {
        $result = requestPasswordReset("reset@example.com", $this->conn);
        $userID = $result['userID'];
        $success = resetPassword($userID, "NewPass123!", $this->conn);
        $this->assertTrue($success);
    }

    protected function tearDown(): void {
        $result = mysqli_query($this->conn, "SELECT userID FROM tblusers WHERE userID = 5");
        $userID = null;
        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $userID = $row['userID'];
        }
        if ($userID) {
            mysqli_query($this->conn, "DELETE FROM tblbookstatus WHERE updatedBy = $userID");
            mysqli_query($this->conn, "DELETE FROM tblbook_ownership WHERE userID = $userID");
            mysqli_query($this->conn, "DELETE FROM tblpasswordresets WHERE userID = $userID");
            mysqli_query($this->conn, "DELETE FROM tblusers WHERE userID = $userID");
        }
        mysqli_close($this->conn);
    }
}