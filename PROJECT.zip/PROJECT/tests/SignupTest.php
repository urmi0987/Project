<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
#define('PHPUNIT_TESTING', true);
use PHPUnit\Framework\TestCase;
require_once dirname(__DIR__) . '/functions.php';

class SignupTest extends TestCase {
    private $conn;

    protected function setUp(): void {
        $this->conn = mysqli_connect("localhost", "root", "", "book_collection_tracker");
        $this->assertNotFalse($this->conn, 'Database connection failed');
        // Clean up test users
        $users = ['testuser', 'user1', 'user2'];
        foreach ($users as $user) {
            $result = mysqli_query($this->conn, "SELECT userID FROM tblusers WHERE username = '$user' OR email = 'testuser@example.com'");
            $userID = null;
            if ($result && mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
                $userID = $row['userID'];
            }
            if ($userID) {
                mysqli_query($this->conn, "DELETE FROM tblbookstatus WHERE updatedBy = $userID");
                mysqli_query($this->conn, "DELETE FROM tblbook_ownership WHERE userID = $userID");
                mysqli_query($this->conn, "DELETE FROM tblpasswordresets WHERE userID = $userID");
                mysqli_query($this->conn, "DELETE FROM tblusers WHERE userID = $userID");
            }
        }
    }

    public function testSignupNormal() {
        $result = signup("testuser", "testuser@example.com", "Pass123!", $this->conn);
        $this->assertTrue($result);
        $row = mysqli_fetch_assoc(mysqli_query($this->conn, "SELECT username FROM tblusers WHERE username = 'testuser'"));
        $this->assertEquals("testuser", $row['username']);
    }

    public function testSignupDuplicateEmail() {
        signup("user1", "testuser@example.com", "Pass123!", $this->conn);
        $result = signup("user2", "testuser@example.com", "Pass123!", $this->conn);
        $this->assertFalse($result);
    }

    protected function tearDown(): void {
        $users = ['testuser', 'user1', 'user2'];
        foreach ($users as $user) {
            $result = mysqli_query($this->conn, "SELECT userID FROM tblusers WHERE username = '$user' OR email = 'testuser@example.com'");
            $userID = null;
            if ($result && mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
                $userID = $row['userID'];
            }
            if ($userID) {
                mysqli_query($this->conn, "DELETE FROM tblbookstatus WHERE updatedBy = $userID");
                mysqli_query($this->conn, "DELETE FROM tblbook_ownership WHERE userID = $userID");
                mysqli_query($this->conn, "DELETE FROM tblpasswordresets WHERE userID = $userID");
                mysqli_query($this->conn, "DELETE FROM tblusers WHERE userID = $userID");
            }
        }
        mysqli_close($this->conn);
    }
}