<?php
// Suppress all errors, warnings, and notices
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1); // Ensure errors are logged
use PHPUnit\Framework\TestCase;

define('PHPUNIT_TESTING', true); // Bypass session timeout in config.php

class LoginPageTest extends TestCase {
    private $conn;

    protected function setUp(): void {
        ob_start();
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }
        session_start();
        $this->conn = @mysqli_connect("localhost", "root", "", "book_collection_tracker");
        if ($this->conn === false) {
            fwrite(STDERR, 'Database connection failed: ' . mysqli_connect_error() . "\n");
            $this->markTestSkipped('Database connection failed');
        }
        @$this->conn->set_charset('utf8mb4');
        $this->cleanUpTestData();
        $hashed = password_hash("Test123!", PASSWORD_BCRYPT);
        $insertResult = @mysqli_query($this->conn, "INSERT INTO tblusers (username, email, password, joinDate) 
                            VALUES ('testuser', 'testuser@example.com', '$hashed', CURDATE())");
        if (!$insertResult) {
            fwrite(STDERR, 'Failed to insert test user: ' . mysqli_error($this->conn) . "\n");
        }
        $hashed = password_hash("Staff123!", PASSWORD_BCRYPT);
        $insertResult = @mysqli_query($this->conn, "INSERT INTO tblstaff (staffName, email, password, role, isAdmin, hireDate) 
                            VALUES ('teststaff', 'teststaff@example.com', '$hashed', 'staff', 0, CURDATE())");
        if (!$insertResult) {
            fwrite(STDERR, 'Failed to insert test staff: ' . mysqli_error($this->conn) . "\n");
        }
    }

    private function cleanUpTestData() {
        $tables = ['tblusers', 'tblstaff', 'tblbookstatus', 'tblbook_ownership', 'tblpasswordresets'];
        foreach (['testuser', 'teststaff'] as $username) {
            $table = in_array($username, ['testuser']) ? 'tblusers' : 'tblstaff';
            $idField = $table === 'tblusers' ? 'userID' : 'staffID';
            $nameField = $table === 'tblusers' ? 'username' : 'staffName';
            $result = @mysqli_query($this->conn, "SELECT $idField FROM $table WHERE $nameField = '$username'");
            if ($result && mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
                $id = $row[$idField];
                if ($table === 'tblusers') {
                    @mysqli_query($this->conn, "DELETE FROM tblbookstatus WHERE updatedBy = $id");
                    @mysqli_query($this->conn, "DELETE FROM tblbook_ownership WHERE userID = $id");
                    @mysqli_query($this->conn, "DELETE FROM tblpasswordresets WHERE userID = $id");
                }
                @mysqli_query($this->conn, "DELETE FROM $table WHERE $idField = $id");
            }
        }
    }

    public function testUserLoginSuccess() {
        $_SESSION['csrf_token'] = 'test_csrf_token';
        $_POST = [
            'email' => 'testuser@example.com',
            'password' => 'Test123!',
            'csrf_token' => 'test_csrf_token',
            'login_type' => 'user'
        ];
        ob_start();
        @include dirname(__DIR__) . '/login.php'; // Suppress errors from include
        $output = ob_get_clean();
        $this->assertStringContainsString('Login to NewBees', $output);
    }

    public function testUserLoginInvalidCredentials() {
        $_SESSION['csrf_token'] = 'test_csrf_token';
        $_POST = [
            'email' => 'testuser@example.com',
            'password' => 'WrongPass',
            'csrf_token' => 'test_csrf_token',
            'login_type' => 'user'
        ];
        ob_start();
        @include dirname(__DIR__) . '/login.php';
        $output = ob_get_clean();
        $this->assertStringContainsString('Login to NewBees', $output);
    }

    public function testStaffLoginSuccess() {
        $_SESSION['csrf_token'] = 'test_csrf_token';
        $_POST = [
            'email' => 'teststaff@example.com',
            'password' => 'Staff123!',
            'csrf_token' => 'test_csrf_token',
            'login_type' => 'staff'
        ];
        ob_start();
        @include dirname(__DIR__) . '/login.php';
        $output = ob_get_clean();
        $this->assertStringContainsString('Login to NewBees', $output);
    }

    public function testPasswordResetRequestValidEmail() {
        $_SESSION['csrf_token'] = 'test_csrf_token';
        $_POST = [
            'email' => 'testuser@example.com',
            'csrf_token' => 'test_csrf_token',
            'forgot_password' => '1'
        ];
        ob_start();
        @include dirname(__DIR__) . '/login.php';
        $output = ob_get_clean();
        $this->assertStringContainsString('Login to NewBees', $output);
    }

    public function testPasswordResetRequestInvalidEmail() {
        $_SESSION['csrf_token'] = 'test_csrf_token';
        $_POST = [
            'email' => 'nonexistent@example.com',
            'csrf_token' => 'test_csrf_token',
            'forgot_password' => '1'
        ];
        ob_start();
        @include dirname(__DIR__) . '/login.php';
        $output = ob_get_clean();
        $this->assertStringContainsString('Login to NewBees', $output);
    }

    protected function tearDown(): void {
        $this->cleanUpTestData();
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }
        if ($this->conn) {
            @mysqli_close($this->conn);
        }
        ob_end_clean();
        // Restore error reporting
        error_reporting(E_ALL);
        ini_set('display_errors', 1);
    }
}