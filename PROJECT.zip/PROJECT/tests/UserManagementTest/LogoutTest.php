<?php
// Suppress all errors, warnings, and notices
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
use PHPUnit\Framework\TestCase;

define('PHPUNIT_TESTING', true); // Ensure compatibility with config.php

class LogoutTest extends TestCase {
    protected function setUp(): void {
        @ob_start();
        if (session_status() === PHP_SESSION_ACTIVE) {
            @session_destroy();
        }
    }

    public function testLogoutClearsSession() {
        @session_start();
        $_SESSION['userID'] = 2;
        @ob_start();
        @include dirname(__DIR__) . '/logout.php';
        @ob_end_clean();
        $this->assertEmpty($_SESSION);
    }

    public function testLogoutNoSession() {
        @session_start();
        @session_destroy();
        @ob_start();
        @include dirname(__DIR__) . '/logout.php';
        @ob_end_clean();
        $this->assertEmpty($_SESSION);
    }

    protected function tearDown(): void {
        if (session_status() === PHP_SESSION_ACTIVE) {
            @session_destroy();
        }
        @ob_end_clean();
        error_reporting(E_ALL);
        ini_set('display_errors', 1);
    }
}