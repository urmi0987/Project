<?php
// tests/ManageUsersPageTest.php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

class ExitException extends Exception
{
    // This custom exception will be thrown instead of the script exiting
}

final class ManageUsersPageTest extends TestCase
{
    private $conn;
    private const TEST_USER_ID = 99999;

    protected function setUp(): void
    {
        $this->conn = mysqli_connect('localhost', 'root', '', 'book_collection_tracker');
        if (!$this->conn) {
            $this->markTestSkipped('Cannot connect to the database');
        }
        mysqli_set_charset($this->conn, 'utf8mb4');

        $this->cleanUpTestUser(self::TEST_USER_ID);

        $passwordHash = password_hash('TestPassword123!', PASSWORD_DEFAULT);
        $query = sprintf(
            "INSERT INTO tblusers (userID, username, email, password, joinDate) VALUES (%d, '%s', '%s', '%s', CURDATE())",
            self::TEST_USER_ID,
            'testuser99999',
            'testuser99999@example.com',
            $passwordHash
        );
        if (!mysqli_query($this->conn, $query)) {
            $this->markTestSkipped('Failed to insert test user: ' . mysqli_error($this->conn));
        }
    }

    private function cleanUpTestUser(int $userID): void
    {
        if (!$this->conn) {
            return;
        }
        $result = mysqli_query($this->conn, "SELECT userID FROM tblusers WHERE userID = $userID");
        if ($result && mysqli_num_rows($result) > 0) {
            mysqli_query($this->conn, "DELETE FROM tblbookstatus WHERE updatedBy = $userID");
            mysqli_query($this->conn, "DELETE FROM tblbook_ownership WHERE userID = $userID");
            mysqli_query($this->conn, "DELETE FROM tblpasswordresets WHERE userID = $userID");
            mysqli_query($this->conn, "DELETE FROM tblreviews WHERE userID = $userID");
            mysqli_query($this->conn, "DELETE FROM tblratings WHERE userID = $userID");
            mysqli_query($this->conn, "DELETE FROM tblusers WHERE userID = $userID");
        }
    }

    private function includeManageUsersPage(array $sessionVars = [], array $postVars = []): string
    {
        // Set session and post variables
        foreach ($sessionVars as $key => $value) {
            $_SESSION[$key] = $value;
        }
        foreach ($postVars as $key => $value) {
            $_POST[$key] = $value;
        }

        try {
            ob_start();
            include __DIR__ . '/../manage_users.php';
            return ob_get_clean();
        } catch (ExitException $e) {
            // Catch the custom ExitException and return the buffered output
            return ob_get_clean();
        }
    }

    public function testAddUserSuccess(): void
    {
        $session = [
            'userID' => 1,
            'role' => 'admin',
            'csrf_token' => 'test_csrf_token',
            'last_activity' => time()
        ];

        $post = [
            'add_user' => '1',
            'username' => 'newuser99999',
            'email' => 'newuser99999@example.com',
            'password' => 'NewPass123!'
        ];

        $output = $this->includeManageUsersPage($session, $post);

        // Check for redirect
        $this->assertStringContainsString('Location: manage_users.php', $output);

        // Verify user got inserted
        $res = mysqli_query($this->conn, "SELECT * FROM tblusers WHERE username = 'newuser99999'");
        $this->assertGreaterThan(0, mysqli_num_rows($res), 'New user was not inserted');

        // Clean up
        if ($res && $row = mysqli_fetch_assoc($res)) {
            $this->cleanUpTestUser((int)$row['userID']);
        }
    }

    public function testUpdateUserSuccess(): void
    {
        $session = [
            'userID' => 1,
            'role' => 'admin',
            'csrf_token' => 'test_csrf_token',
            'last_activity' => time()
        ];

        $post = [
            'update_user' => '1',
            'userID' => self::TEST_USER_ID,
            'username' => 'updateduser99999',
            'email' => 'updateduser99999@example.com',
            'password' => ''
        ];

        $output = $this->includeManageUsersPage($session, $post);

        // Check for redirect
        $this->assertStringContainsString('Location: manage_users.php', $output);

        // Confirm update
        $res = mysqli_query($this->conn, "SELECT username, email FROM tblusers WHERE userID = " . self::TEST_USER_ID);
        $row = mysqli_fetch_assoc($res);
        $this->assertEquals('updateduser99999', $row['username']);
        $this->assertEquals('updateduser99999@example.com', $row['email']);

        // Revert user back
        $origPass = password_hash('TestPassword123!', PASSWORD_DEFAULT);
        mysqli_query($this->conn, sprintf(
            "UPDATE tblusers SET username='testuser99999', email='testuser99999@example.com', password='%s' WHERE userID=%d",
            $origPass,
            self::TEST_USER_ID
        ));
    }

    public function testDeleteUserSuccess(): void
    {
        // Insert user to delete
        $pass = password_hash('DeletePass123!', PASSWORD_DEFAULT);
        mysqli_query($this->conn, sprintf(
            "INSERT INTO tblusers (userID, username, email, password, joinDate) VALUES (99998, 'deleteuser99998', 'deleteuser99998@example.com', '%s', CURDATE())",
            $pass
        ));

        $session = [
            'userID' => 1,
            'role' => 'admin',
            'csrf_token' => 'test_csrf_token',
            'last_activity' => time()
        ];

        $post = [
            'delete_user' => '1',
            'userID' => 99998,
        ];

        $output = $this->includeManageUsersPage($session, $post);

        // Check for redirect
        $this->assertStringContainsString('Location: manage_users.php', $output);

        // Confirm deletion
        $res = mysqli_query($this->conn, "SELECT * FROM tblusers WHERE userID = 99998");
        $this->assertEquals(0, mysqli_num_rows($res));
    }

    public function testAccessDeniedNonAdmin(): void
    {
        $session = [
            'userID' => 2,
            'role' => 'user',
            'csrf_token' => 'test_csrf_token',
            'last_activity' => time()
        ];

        $output = $this->includeManageUsersPage($session);

        // Should redirect to dashboard.php - no HTML output
        $this->assertStringContainsString('Location: dashboard.php', $output);
    }

    protected function tearDown(): void
    {
        $this->cleanUpTestUser(self::TEST_USER_ID);

        if ($this->conn) {
            mysqli_close($this->conn);
        }
    }
}