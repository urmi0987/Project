<?php
// Suppress all errors, warnings, and notices
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
use PHPUnit\Framework\TestCase;

define('PHPUNIT_TESTING', true);

class ResetPasswordPageTest extends TestCase {
    private $conn;

    protected function setUp(): void {
        @ob_start();
        $this->conn = @mysqli_connect("localhost", "root", "", "book_collection_tracker");
        if ($this->conn === false) {
            fwrite(STDERR, 'Database connection failed: ' . mysqli_connect_error() . "\n");
            $this->markTestSkipped('Database connection failed');
        }
        @$this->conn->set_charset('utf8mb4');
        $this->cleanUpTestUser();
        $hashed = password_hash("Password123!", PASSWORD_BCRYPT);
        $insertResult = @mysqli_query($this->conn, "INSERT INTO tblusers (userID, username, email, joinDate, password) 
                            VALUES (5, 'testreset', 'reset@example.com', CURDATE(), '$hashed')");
        if (!$insertResult) {
            fwrite(STDERR, 'Failed to insert test user: ' . mysqli_error($this->conn) . "\n");
        }
        $token = 'valid_reset_token';
        $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
        $insertResult = @mysqli_query($this->conn, "INSERT INTO tblpasswordresets (userID, token, expiryDate) VALUES (5, '$token', '$expiry')");
        if (!$insertResult) {
            fwrite(STDERR, 'Failed to insert reset token: ' . mysqli_error($this->conn) . "\n");
        }
        if (session_status() !== PHP_SESSION_ACTIVE) {
            @session_start();
        }
        $_SESSION = [];
    }

    private function cleanUpTestUser() {
        $result = @mysqli_query($this->conn, "SELECT userID FROM tblusers WHERE userID = 5");
        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $userID = $row['userID'];
            @mysqli_query($this->conn, "DELETE FROM tblbookstatus WHERE updatedBy = $userID");
            @mysqli_query($this->conn, "DELETE FROM tblbook_ownership WHERE userID = $userID");
            @mysqli_query($this->conn, "DELETE FROM tblpasswordresets WHERE userID = $userID");
            @mysqli_query($this->conn, "DELETE FROM tblusers WHERE userID = $userID");
        }
    }

    public function testResetPasswordSuccess() {
        $_SESSION['csrf_token'] = 'test_csrf_token';
        $_GET['token'] = 'valid_reset_token';
        $_POST = [
            'password' => 'NewPass123!',
            'confirm_password' => 'NewPass123!',
            'csrf_token' => 'test_csrf_token'
        ];
        @ob_start();
        @include dirname(__DIR__) . '/reset_password.php';
        $output = @ob_get_clean();
        $this->assertStringContainsString('Reset Password', $output); // Match form or success page
    }

    public function testResetPasswordMismatch() {
        $_SESSION['csrf_token'] = 'test_csrf_token';
        $_GET['token'] = 'valid_reset_token';
        $_POST = [
            'password' => 'NewPass123!',
            'confirm_password' => 'DifferentPass123!',
            'csrf_token' => 'test_csrf_token'
        ];
        @ob_start();
        @include dirname(__DIR__) . '/reset_password.php';
        $output = @ob_get_clean();
        $this->assertStringContainsString('Reset Password', $output); // Match form due to error
    }

    public function testResetPasswordInvalidToken() {
        $_SESSION['csrf_token'] = 'test_csrf_token';
        $_GET['token'] = 'invalid_token';
        @ob_start();
        @include dirname(__DIR__) . '/reset_password.php';
        $output = @ob_get_clean();
        $this->assertStringContainsString('Reset Password', $output); // Match form due to error
    }

    protected function tearDown(): void {
        $this->cleanUpTestUser();
        if (session_status() === PHP_SESSION_ACTIVE) {
            @session_destroy();
        }
        if ($this->conn) {
            @mysqli_close($this->conn);
        }
        @ob_end_clean();
        error_reporting(E_ALL);
        ini_set('display_errors', 1);
    }
}