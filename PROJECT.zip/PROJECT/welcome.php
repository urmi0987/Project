<?php
ob_start(); // Start output buffering
session_start();
if (isset($_SESSION['userID'])) {
  header('Location: dashboard.php');
  exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Welcome to NewBees</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
  <style>
    html, body {
      height: 100%;
      margin: 0;
    }
    body {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
    main {
      flex: 1 0 auto;
    }
    footer {
      flex-shrink: 0;
    }
    .hero-bg {
      background: linear-gradient(to bottom, #e0f2fe, #f3e8ff);
      min-height: 70vh;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
    }
    .hero-image {
      background-image: url('https://ik.imagekit.io/storybird/images/ce2cfaaa-6b60-460a-a15e-3f538a29aae1/23_264039720.webp');
      background-size: cover;
      background-position: center;
      width: 40%;
      height: 500px;
      border-radius: 15px;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
      position: relative;
    }
    .hero-image::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: linear-gradient(to bottom, rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.3));
      border-radius: 15px;
    }
    .hero-text {
      width: 60%;
      padding-left: 4rem;
      color: #1e293b;
    }
    .logo-text {
      font-size: 3rem;
      font-weight: bold;
      color: #4f46e5;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1);
    }
    .feature-card {
      background: linear-gradient(to bottom, #ffffff, #f9fafb);
      border: 1px solid #e5e7eb;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .feature-card:hover {
      transform: scale(1.05);
      box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
    }
    .testimonial-card {
      background: #ffffff;
      border: 1px solid #e5e7eb;
      border-radius: 15px;
      padding: 2rem;
      margin: 1rem;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
    }
    .scroll-reveal {
      opacity: 0;
      transform: translateY(50px);
      transition: opacity 0.8s ease, transform 0.8s ease;
    }
    .scroll-reveal.visible {
      opacity: 1;
      transform: translateY(0);
    }
    @media (max-width: 768px) {
      .hero-bg {
        flex-direction: column;
        min-height: 90vh;
      }
      .hero-image {
        width: 100%;
        height: 300px;
        margin-bottom: 2rem;
      }
      .hero-text {
        width: 100%;
        padding-left: 0;
        text-align: center;
      }
      .logo-text {
        font-size: 2.5rem;
      }
    }
  </style>
</head>
<body class="font-sans">
  <main class="flex-1">
    <!-- Hero Section -->
    <header class="hero-bg">
      <div class="container mx-auto flex items-center px-4">
        <div class="hero-image animate__animated animate__fadeInLeft"></div>
        <div class="hero-text animate__animated animate__fadeInRight">
          <h1 class="logo-text mx-auto md:mx-0">NewBees</h1>
          <h1 class="text-5xl md:text-6xl font-bold text-indigo-700 mb-4 leading-tight">Welcome to NewBees</h1>
          <p class="text-lg md:text-xl text-gray-700 mb-8 max-w-lg">
            Unleash your passion for reading with NewBees! Organize your collection, track your progress, and join a vibrant community of book lovers.
          </p>
          <a href="login.php" class="bg-gradient-to-r from-indigo-600 to-purple-700 text-white px-8 py-4 rounded-lg hover:from-indigo-700 hover:to-purple-800 text-lg font-semibold transition-all duration-300">
            Get Started
          </a>
        </div>
      </div>
    </header>

    <!-- Features Section -->
    <section class="py-20 bg-white">
      <div class="container mx-auto text-center">
        <h2 class="text-4xl font-bold text-indigo-700 mb-12 scroll-reveal">What Makes NewBees Special?</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 px-4">
          <div class="feature-card p-6 rounded-lg scroll-reveal">
            <i class="fas fa-book text-4xl text-indigo-600 mb-4"></i>
            <h3 class="text-xl font-semibold text-gray-800 mb-2">Organize Your Library</h3>
            <p class="text-gray-600">Categorize books by genre, track statuses, and add ratings effortlessly.</p>
          </div>
          <div class="feature-card p-6 rounded-lg scroll-reveal" style="transition-delay: 0.2s;">
            <i class="fas fa-check-circle text-4xl text-indigo-600 mb-4"></i>
            <h3 class="text-xl font-semibold text-gray-800 mb-2">Track Your Progress</h3>
            <p class="text-gray-600">Monitor your reading journey and set goals for every book.</p>
          </div>
          <div class="feature-card p-6 rounded-lg scroll-reveal" style="transition-delay: 0.4s;">
            <i class="fas fa-users text-4xl text-indigo-600 mb-4"></i>
            <h3 class="text-xl font-semibold text-gray-800 mb-2">Join the Community</h3>
            <p class="text-gray-600">Share reviews, discover new reads, and connect with book enthusiasts.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Testimonials Section -->
    <section class="py-20 bg-gradient-to-r from-indigo-50 to-purple-50">
      <div class="container mx-auto text-center">
        <h2 class="text-4xl font-bold text-indigo-700 mb-12 scroll-reveal">What Our Users Say</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 px-4">
          <div class="testimonial-card scroll-reveal">
            <p class="text-gray-700 mb-4">"NewBees transformed how I manage my books. I love the community features!"</p>
            <p class="font-semibold text-gray-800">— Suraiya Urmi</p>
          </div>
          <div class="testimonial-card scroll-reveal" style="transition-delay: 0.2s;">
            <p class="text-gray-700 mb-4">"Tracking my reading progress has never been easier. Highly recommend!"</p>
            <p class="font-semibold text-gray-800">— Sifat Miya</p>
          </div>
          <div class="testimonial-card scroll-reveal" style="transition-delay: 0.4s;">
            <p class="text-gray-700 mb-4">"A must-have for any book lover. The design is sleek and intuitive."</p>
            <p class="font-semibold text-gray-800">— Sadeka Jahan</p>
          </div>
        </div>
      </div>
    </section>

    <!-- CTA Section -->
    <section class="py-20 bg-gradient-to-r from-indigo-600 to-purple-700 text-center text-white">
      <div class="container mx-auto scroll-reveal">
        <h2 class="text-4xl font-bold mb-6">Ready to Start Your Reading Journey?</h2>
        <p class="text-xl mb-8 max-w-2xl mx-auto">
          Join thousands of book lovers on NewBees and take your reading experience to the next level.
        </p>
        <a href="login.php" class="bg-white text-indigo-700 px-8 py-4 rounded-lg hover:bg-gray-100 text-lg font-semibold transition-all duration-300">Join Now</a>
        <p class="mt-4 text-sm">
          <a href="terms.php" class="text-gray-300 hover:text-white">Terms & Conditions</a> |
          <a href="privacy.php" class="text-gray-300 hover:text-white">Privacy Policy</a>
        </p>
      </div>
    </section>
  </main>

  <?php require_once 'footer.php'; ?>
  <?php ob_end_flush(); ?>

  <script>
    const scrollReveals = document.querySelectorAll('.scroll-reveal');
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
        }
      });
    }, { threshold: 0.1 });

    scrollReveals.forEach(el => observer.observe(el));
  </script>
</body>
</html>